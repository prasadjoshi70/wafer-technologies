<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class departmentController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('departmentModel');
	}
	function index(){
		$data = array();
		$data['page_title'] = D_HOME;
		$data['is_selected'] = "dhome";
		
		$this->content['content'] = $this->parser->parse('department_home.php',$data,true);
		$this->adminTemplate();
	}
	
	function saveStudentData(){
		$handle=fopen($_FILES['ufile']['tmp_name'],'r');
		$result=array();
		while($data=fgetcsv($handle,1000,',')){
			$result[]=$data;
		}
		$res=$this->departmentModel->updateRecord($result);
		$this->session->set_flashdata('success',"Data imported successfully");
		redirect(D_HOME_PAGE_URL, 'refresh');
		
	}
}


?>