<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class adminController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('adminModel');
	}
	function index(){
		$data = array();
		$data['page_title'] = STUDENT_LIST;
		$data['is_selected'] = "studentlist";
		$params=array();
		$params['stream']=(isset($_POST['stream'])) ? $_POST['stream'] : null; 
		$data['studentList'] = $this->adminModel->studentlist($params);
		$data['streamSelected']=$params['stream'];
		$this->content['content'] = $this->parser->parse('student_list.php',$data,true);
		$this->adminTemplate();
	}
	
	function candidateList(){
		$data = array();
		$data['page_title'] = CANDIDATE_LIST;
		$data['is_selected'] = "candidatelist";
		$params=array();
		$params['stream']=(isset($_POST['stream'])) ? $_POST['stream'] : null; 
		$data['studentList'] = $this->adminModel->candidatelist($params);
		$data['streamSelected']=$params['stream'];
		$this->content['content'] = $this->parser->parse('candidate_list.php',$data,true);
		$this->adminTemplate();
	}
	
	function addcourse(){
		$data = array();
		$data['page_title'] = COURSE;
		$data['is_selected'] = "addcourse";
		$this->content['content'] = $this->parser->parse('course.php',$data,true);
		$this->adminTemplate();
	}

	function saveCourse()
	{
		$this->load->library('form_validation');	
		$this->form_validation->set_rules('c_name','Course','trim|required|is_unique[course.c_name]');
		$this->form_validation->set_rules('email','Email','trim|required|is_unique[course.email]');

		
		if ($this->form_validation->run() == true)
        {
		$params = array('password' => md5($this->input->post('password')),
		 'd_id' => $this->input->post('department'),
		 'c_name' => $this->input->post('c_name'),
		 'email' => $this->input->post('email'));
		 
		$this->load->model('adminModel');
		$this->adminModel->saveCourse($params);

		 $params2 = array('password' => md5($this->input->post('password')),
		 'stream' => $this->input->post('c_name'),
		 's_first' => $this->input->post('c_name'),
		 's_middle' => $this->input->post('c_name'),
		 's_last' => $this->input->post('c_name'),
		 'address' => $this->input->post('c_name'),
		 'department' => $this->input->post('department'),
		 'email' => $this->input->post('email'),
		 'user_type' => 3,
		 'flag' => 1
		 );

		$this->adminModel->saveStudent($params2);
		$this->session->set_flashdata('success',"Course included Successfully");
		redirect(BASE_URL.S_COURSE_URL);
		}
		else
		{
			$this->session->set_flashdata('success',"Invalid data");
			redirect(BASE_URL.S_COURSE_URL);
		}
	}
	
	function exportStudentCSV(){

		$params=array();
		$params['stream']=(isset($_POST['stream'])) ? $_POST['stream'] : null; 
		
		$filename = "studentlist.csv";
		$fp = fopen('php://output', 'w');
		header('Content-type: application/csv');
		header('Content-Disposition: attachment; filename='.$filename);
		$header=array("id","Type","First Name","Middle Name","Last Name","Address","Department","Stream","Email","Gender","Phone","Part","flag");
		fputcsv($fp, $header);		
		$result=$this->adminModel->studentlist($params);

		if (count($result) > 0) {
					foreach($result as $row){
			fputcsv($fp, $row);
		}
		}

		exit;	
	}

	function get()
	{
		$this->load->model('studentModel');
		$data = $this->studentModel->getStudentsForDepartment($this->input->post('matchvalue'));
		print_r(json_encode($data));
	}

	
	function getCourses()
	{
		$this->load->model('courseModel');
		$data = $this->courseModel->getCourses();
		print_r(json_encode($data));
	}

	
	function getList()
	{
		$this->load->model('studentModel');
		$data = $this->studentModel->getStudents($this->input->post('stream'));
		print_r(json_encode($data));
	}

}


?>