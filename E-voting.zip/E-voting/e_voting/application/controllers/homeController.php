<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class homeController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('homeModel');
	}
	function index(){
		$data = array();
		$data['page_title'] = HOME;
		$data['is_selected'] = "home";
		if(isset($_SESSION['logindata'])){
			if($_SESSION['logindata']['user_type']==1){
				redirect(S_HOME_PAGE_URL, 'refresh');
			}elseif($_SESSION['logindata']['user_type']==2){
				redirect(S_STUDENTLIST_URL, 'refresh');
			}else{
				redirect(D_HOME_PAGE_URL, 'refresh');
			}
		}else{
			$this->content['content'] = $this->parser->parse('home.php',$data,true);
			$this->renderTemplate();
		}
		
	}
	
	function register(){
		$data = array();
		$data['page_title'] = REGISTER;
		$data['is_selected'] = "register";
		
		$this->content['content'] = $this->parser->parse('register.php',$data,true);
		$this->renderTemplate();
	}
	
	function registerForm(){
		$this->load->library('form_validation');	
		$this->form_validation->set_rules('s_first','First','trim|required|alpha');
		$this->form_validation->set_rules('s_middle','Middle','trim|required|alpha');
		$this->form_validation->set_rules('s_last','Last','trim|required|alpha');
		$this->form_validation->set_rules('email','Email','trim|required|is_unique[student.email]');
		$this->form_validation->set_rules('phone','Phone','required|regex_match[/^[0-9]{10}$/]');
		if ($this->form_validation->run() == true)
        {
		$insertdata = $this->homeModel->saveForm($_POST);
		$this->session->set_flashdata('success',"User Registered Successfully");
		redirect(BASE_URL.HOME_PAGE_URL);
		}
		else
		{
			$this->session->set_flashdata('success',"Invalid data");
			redirect(BASE_URL.REGISTER_URL);
		}
	}
	
	function Login(){
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email','Email','trim|required');
		if ($this->form_validation->run() == true)
        {
		$email=$this->input->post('email');
		$data = $this->homeModel->loginDetails($_POST);
		if(is_array($data)){
			$session_data=array(
			'email'=>$email
			);
			$this->session->set_userdata($session_data);
			echo $data['user_type'];
			return;
		}
		echo 5;
		return;
		}	
	}
	
	function logout(){
		$_SESSION['logindata'] = NULL;
		unset($_SESSION['logindata']);
		session_destroy();
		redirect(HOME_PAGE_URL, 'refresh');
	}
}


?>