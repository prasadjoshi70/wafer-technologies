<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class voteController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model(array('voteModel'));
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('url');
		//$this->load->database();
	}
	function index(){	
		
	}
	
	public function castView1()
	{		
		$dataVote= NULL;
		extract($_POST);	
		$params = array();
		$candiFields =array();
		$params['page_title'] = HOME;
		$params['is_selected'] = "vote";

			$this->db->select('*');
			$this->db->from('student');
		    $this->db->where('email', $this->session->userdata('email') );
		    $this->db->where('flag',1);
			$query = $this->db->get();
			if($query->num_rows() > 0)
		{
			$row = $query->row();
			$prop_id=$row->s_id;
			$prop_first=$row->s_first;
			$prop_last=$row->s_last;
			$prop_email=$row->email;
			$prop_dept=$row->department;
			$prop_stream=$row->stream;
			$prop_part=$row->part;
			$fullName = "$prop_first "."$prop_last"; 
		}
			$count=null;;
			if($this->voteModel->checkIfVoted($prop_id,$params))
			{
			$dataVote=$this->voteModel->displayCandidate($dataVote,$prop_dept,$prop_stream,$prop_part,$count);
			$dataVote['page_title']=VOTE;
			$this->content['content'] = $this->parser->parse('vote.php',$dataVote,true);
			$this->adminTemplate();
			$count=$this->voteModel->countCandidates($count,$dataVote,$prop_dept,$prop_stream,$prop_part);	
			}
			else
			{
				redirect(BASE_URL().'homeController');
				echo '<span style="color:red;text-align:center;font-size:30px;">Already Voted</span>';
			}	
	}
		  
		   
	function votedCand()
	{
		$newC_Id1 = NULL;
		$newC_Id2 = NULL;
		$newP_Id1 = NULL;
		$prop_dept=NULL;
		$prop_stream=NULL;
		$prop_part=NULL;
		$newP_Id2 = NULL;
		$c=NULL;
		$count1=0;
		$count2=0;
		$data1 =array();
		$data= $this->input->post();
		
		echo '<pre>';
		print_r($data);
		echo '</pre>';
		echo 'check';
		echo count($data);
		echo 'check';
					
			$params =array();
		
		
			if((!empty($data['candType'][0])) and (!empty($data['candType'][1])))
			{
				$data1['id1']=$data['candType'][0];
				$data1['id2']=$data['candType'][1];
				$newC_Id1=$this->voteModel->getC_Id1($data1['id1'],$newC_Id1);
				$newC_Id2=$this->voteModel->getC_Id2($data1['id2'],$newC_Id2);
				$newP_Id1=$this->voteModel->getP_Id1($data1['id1'],$newP_Id1);
				$newP_Id2=$this->voteModel->getP_Id2($data1['id2'],$newP_Id2);
			
				$this->db->select('*');
				$this->db->from('student');
				$this->db->where('email', $this->session->userdata('email') );
				$this->db->where('flag',1);
				$query = $this->db->get();
				if($query->num_rows() > 0)
				{
					$row = $query->row();
					$prop_id=$row->s_id;
					$prop_first=$row->s_first;
					$prop_last=$row->s_last;
					$prop_email=$row->email;
					$prop_dept=$row->department;
					$prop_stream=$row->stream;
					$prop_part=$row->part;
					$fullName = "$prop_first "."$prop_last"; 
				}
					$data1['c1'] = $newC_Id1;
					$data1['c2'] = $newC_Id2;
					$data1['p1'] = $newP_Id1;
					$data1['p2'] = $newP_Id2;
					$data1['deptV'] = $prop_dept;
					$data1['streamV'] = $prop_stream;
					$data1['partV'] = $prop_part;
					
					if(($this->voteModel->checkIfexists($newC_Id1)) and ($this->voteModel->checkIfexists1($newC_Id2)))
				{
					$prop_id=$this->voteModel->checkIfVoted($prop_id,$params);
					$this->voteModel->countVotesC1($newC_Id1);
					$this->voteModel->countVotesC2($newC_Id2);
					$params = array('voted' => 1);
					$this->voteModel->setToVoted($prop_id,$params);
				}
				else if((($this->voteModel->checkIfexists($newC_Id1))==true) and (($this->voteModel->checkIfexists1($newC_Id2))==false))
				{
					$prop_id=$this->voteModel->checkIfVoted($prop_id,$params);
					$this->voteModel->countVotesC1($newC_Id1);
					$this->voteModel->updateC2($data1);
					$this->voteModel->countVotesC2($newC_Id2);
					$params = array('voted' => 1);
					$this->voteModel->setToVoted($prop_id,$params);
				
				}
				else if((($this->voteModel->checkIfexists($newC_Id1))==false) and (($this->voteModel->checkIfexists1($newC_Id2))==true))
				{
					$prop_id=$this->voteModel->checkIfVoted($prop_id,$params);
					$this->voteModel->updateC1($data1);
					$this->voteModel->countVotesC1($newC_Id1);
					$this->voteModel->countVotesC2($newC_Id2);
					$params = array('voted' => 1);
					$this->voteModel->setToVoted($prop_id,$params);
				}
				else 
				{
					$this->voteModel->updateC1($data1);
					$this->voteModel->updateC2($data1);
					$this->voteModel->countVotesC1($newC_Id1);
					$this->voteModel->countVotesC2($newC_Id2);
				}
			}
			else if((!empty($data['candType'][0])) and (empty($data['candType'][1])))
			{
				
				$data1['id1']=$data['candType'][0];
				$newC_Id1=$this->voteModel->getC_Id1($data1['id1'],$newC_Id1);
				$newP_Id1=$this->voteModel->getP_Id1($data1['id1'],$newP_Id1);
				$this->db->select('*');
				$this->db->from('student');
				$this->db->where('email', $this->session->userdata('email') );
				$this->db->where('flag',1);
				$query = $this->db->get();
				if($query->num_rows() > 0)
				{
					$row = $query->row();
					$prop_id=$row->s_id;
					$prop_first=$row->s_first;
					$prop_last=$row->s_last;
					$prop_email=$row->email;
					$prop_dept=$row->department;
					$prop_stream=$row->stream;
					$prop_part=$row->part;
					$fullName = "$prop_first "."$prop_last"; 
				}
					$data1['c1'] = $newC_Id1;
					$data1['p1'] = $newP_Id1;
					$data1['deptV'] = $prop_dept;
					$data1['streamV'] = $prop_stream;
					$data1['partV'] = $prop_part;
					
					if(($this->voteModel->checkIfexists($newC_Id1))==true)
				{
					$prop_id=$this->voteModel->checkIfVoted($prop_id,$params);
					$this->voteModel->countVotesC1($newC_Id1);
					$params = array('voted' => 1);
					$this->voteModel->setToVoted($prop_id,$params);
				}
				else if(($this->voteModel->checkIfexists($newC_Id1))==false)
				{
					$this->voteModel->updateC1($data1);
					$this->voteModel->countVotesC1($newC_Id1);
				}
			}
			else if((empty($data['candType'][0])) and (empty($data['candType'][1])))
			{
				echo 'Not selected any option!';
			}	
			
			redirect(BASE_URL().'homeController');
	}
	
	function logout()
	{
			$this->session->unset_userdata('email');
			redirect(base_url() . 'homeController');
	}
		
}	
?>