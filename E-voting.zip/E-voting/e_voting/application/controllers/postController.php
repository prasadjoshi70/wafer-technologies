<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class postController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model(array('postCandidate'));
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('url');
	}
	
	public function postView1()
	{		
		$this->applyForPost();  
	}
	function applyForPost()
	{
		$pname1 = NULL;
		$postName = 'UCR';
		$sname1 = NULL;
		$emailP = NULL;
		$emailS = NULL;
		$name = NULL;
		$prop_id=NULL;
		$prop_first=NULL;
		$prop_last=NULL;
		$prop_id=NULL;
		$prop_idP=NULL;
		$prop_idS=NULL;
		
		$prop_email = NULL;
		$temp = 0;
		$temp1=0;
	
		extract($_POST);
		
		$params = array();
		$candiFields =array();
		$params['page_title'] = HOME;
		$params['is_selected'] = "postView";
		$this->db->select('*');
		$this->db->from('student');
		$this->db->where('email', $this->session->userdata('email') );
		$this->db->where('flag',1);
		$query = $this->db->get();
		if($query->num_rows() > 0)
	{
		$row = $query->row(); 
		echo $prop_id=$row->s_id;
		 $prop_first=$row->s_first;
		 $prop_last=$row->s_last;
		 $prop_email=$row->email;
		 echo $prop_dept=$row->department;
		 echo $prop_stream=$row->stream;
		 echo $prop_part=$row->part;
		$fullName = "$prop_first "."$prop_last"; 
		$rows = $query->result();
		$data = array(
		'result' => $rows
		);
		$data['page_title'] = POST;
		$this->content['content'] = $this->parser->parse('postView.php',$data,true);	
		$this->adminTemplate();	
	}
		
		$params['pname1'] = $pname1;
		$params['postName'] = $postName;
		$params['sname1'] = $sname1;
		$params['emailP'] = $emailP;
		$params['emailS'] = $emailS;
		
		if (isset($submit))
			{
					
					if(($qw=$this->postCandidate->check($params['pname1'],$params['sname1'],$prop_idP,$prop_dept,$prop_stream,$prop_part)) and $this->postCandidate->checkIfCandidateName($params['pname1'],$params['sname1'],$prop_id,$temp1) and ($qwe=$this->postCandidate->check1($params['sname1'],$params['sname1'],$prop_idS,$prop_dept,$prop_stream,$prop_part)) and ($params['sname1']!=$params['pname1']) and ($this->postCandidate->checkIfProposedName($params['pname1'],$params['sname1'],$prop_idP,$temp)) and ($this->postCandidate->candidateNameRepeat($params['pname1'],$params['sname1'],$fullName)))
					{ 
							if($this->postCandidate->checkEmailPn($params['emailP'],$params['emailS'],$params['pname1'],$params['sname1'],$qw) and $this->postCandidate->checkEmailSn($params['emailP'],$params['emailS'],$params['pname1'],$params['sname1'],$qwe) and $this->postCandidate->checkIfSame($params['pname1'],$params['sname1'],$params['emailP'],$params['emailS'],$fullName,$prop_email))
							{
							
								if($qwer=$this->postCandidate->update($params))
								{	
									$candiFields['prop_id'] = $prop_id;
									$candiFields['fullName'] = $fullName;
									$candiFields['qwer'] = $qwer;
									$this->postCandidate->updateCandidate($candiFields);
								}									
								
								}	
					}
					else
					{
						echo 'wrong data';
					}
					
			}
	
	}
	
	function logout()
	{
			$this->session->unset_userdata('email');
			redirect(base_url() . 'homeController');
	}
	
	function index(){
	
	}
	
}


?>