<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class instructionController extends MY_Controller {
	function __construct(){
		parent::__construct();
	}
	function index(){
		$data = array();
		$data['page_title'] = INSTRUCTION;
		$data['is_selected'] = "instruction";
		$this->content['content'] = $this->parser->parse('instruction.php',$data,true);
		$this->renderTemplate();
	}
}
?>