<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class studentController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('studentModel');
	}
	
	function index(){
		$data = array();
		$data['page_title'] = S_HOME;
		$data['is_selected'] = "shome";
		$this->content['content'] = $this->parser->parse('student_home.php',$data,true);
		$this->adminTemplate();
	}
}


?>