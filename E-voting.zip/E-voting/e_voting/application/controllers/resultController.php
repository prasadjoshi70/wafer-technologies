<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class resultController extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model(array('voteModel'));
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('url');
	}

	public function resultView1()
	{
		$dataVote= array();
		$stid=array();
		$prop_id=NULL;
		$prop_dept=NULL;
		$prop_stream=NULL;
		$prop_part=NULL;
		$prop_first=NULL;
		$prop_last=NULL;
		$prop_email=NULL;
		$fullName=NULL;
		$count=NULL;
		$count1=NULL;
		$this->db->select('*');
		$this->db->from('student');
		$this->db->where('email', $this->session->userdata('email') );
		$this->db->where('flag',1);
		$this->db->where('voted',1);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$prop_id=$row->s_id;
			$prop_first=$row->s_first;
			$prop_last=$row->s_last;
			$prop_email=$row->email;
			echo $prop_dept=$row->department;
			echo $prop_stream=$row->stream;
			echo $prop_part=$row->part;
			$fullName = "$prop_first "."$prop_last"; 
			$winner=array();
			$winner1=array();
		
			if(($dataVote=$this->voteModel->displayCandidate1($dataVote,$prop_dept,$prop_stream,$prop_part,$count)) and ($stid=$this->voteModel->countCandidates1($stid,$prop_dept,$prop_stream,$prop_part,$count)))
			{
				$winner=$this->voteModel->results($dataVote,$stid);
				$count=$this->voteModel->resultsCount($dataVote,$stid,$count);
				$winner1=$this->voteModel->results1($dataVote,$count,$stid);
				$data['result'] = $winner;
				$data['result1'] = $winner1;
				$data['page_title'] = RESULT;
				$this->content['content'] = $this->parser->parse('resultView.php',$data,true);
				$this->adminTemplate();
			}					
			else
			{
				echo "No winner!";
			}					
		}
		else
		{
			redirect(BASE_URL().'homeController');
		}
		
	}
	
	function logout()
	{
			$this->session->unset_userdata('email');
			redirect(base_url() . 'homeController');
	}
		
}	
?>