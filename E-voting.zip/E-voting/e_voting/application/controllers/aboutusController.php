<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class aboutusController extends MY_Controller {
	function __construct(){
		parent::__construct();
	}
	function index(){
		$data = array();
		$data['page_title'] = ABOUT_US;
		$data['is_selected'] = "aboutus";
		$this->content['content'] = $this->parser->parse('aboutus.php',$data,true);
		$this->renderTemplate();
	}
}
?>