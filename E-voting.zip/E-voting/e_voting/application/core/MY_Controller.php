<?php
class MY_Controller extends CI_Controller {
	public $content = array (
			'title' => '',
			'id' => 'default',
			'class' => 'default' 
	);
	function __construct() {
		parent::__construct ();
		//require 'libraries/PHPMailer/class.phpmailer.php';
	}
		
	function renderTemplate() {
		$data = array ();
		//Header Common CSS Files
		$data['bootstrap_min_css']='<link rel="stylesheet" href="css/core/bootstrap.min.css">';
		$data['style_css']='<link rel="stylesheet" href="css/style.css">';
		
		//Footer Common Javascript File
		$data['jqeury_min_js']='<script src="js/core/jquery.min.js"></script>';
		$data['bootstrap_min_js']='<script src="js/core/bootstrap.min.js"></script>';
		$data['myscript_js']='<script src="js/myscript.js"></script>';		
		$data['script_js']='<script src="js/script.js"></script>';
		
		
		$this->content ['header'] = $this->parser->parse ( 'layout/header.php', $data, true );
		$this->content ['footer'] = $this->parser->parse ( 'layout/footer.php', $data, true );
		$this->parser->parse ( 'layout/main.php', $this->content, false );
	}
	
	function adminTemplate() {
		$data = array ();
		//Header Common CSS Files
		$data['bootstrap_min_css']='<link rel="stylesheet" href="css/core/bootstrap.min.css">';
		$data['style_css']='<link rel="stylesheet" href="css/style.css">';
		
		//Footer Common Javascript File
		$data['jqeury_min_js']='<script src="js/core/jquery.min.js"></script>';
		$data['bootstrap_min_js']='<script src="js/core/bootstrap.min.js"></script>';	
		$data['script_js']='<script src="js/script.js"></script>';
		$data['myscript_js']='<script src="js/myscript.js"></script>';
		
		$this->content ['header'] = $this->parser->parse ( 'layout/innerHeader.php', $data, true );
		$this->content ['footer'] = $this->parser->parse ( 'layout/footer.php', $data, true );
		$this->parser->parse ( 'layout/main.php', $this->content, false );
	}
	
	// /**
	 // *Function to send mail
	 // *@Name: sendmail.
	 // *@Parameters:
	 // *@Importance: Function to send mail
	 // *@Compulsary Fields:
	 // *@Common Function: Yes
	 // *
	 // */
	// function sendmail($subject,$message,$email_id, $to_name,$from_id=EMAIL_FROM,$from_name=EMAIL_FROM_NAME,$FileAttachment=null) {
		// $headers = "From:".FROM_EMAIL."\r\n";
		// $headers.= "MIME-version: 1.0\n";
		// $headers.= "Content-type: text/html; charset= utf-8\n";
		// $mail = new PHPMailer();
		// $mail->IsSMTP();
		// $mail->Host = SMTP_HOSTNAME;
		// $mail->SMTPAuth = SMTP_AUTH;
		// $mail->Username = SMTP_USERNAME;
		// $mail->Password = SMTP_PASSWORD;
		// $mail->WordWrap = 50;
		// $mail->IsHTML(true);
		// $mail->From = $from_id;
		// $mail->FromName = $from_name;
		// $mail->AddAddress($email_id, $to_name);
		// $mail->AddEmbeddedImage('images/logo.png', 'logo');
		// $mail->Subject = $subject;
		// $msg_header='<div style="width: 600px;background-color: #8BC34A;margin: 0px auto;height: auto;padding:3px;"><div style="position: relative;width: 600px;background-color: #FFF;margin: 0px auto;"><div style="margin-left: 155px;width: 260px;height: 100px;"><img src="cid:logo"></div><hr><div style="padding: 35px;text-align: justify;">';
		// $msg_note='<br>'.THANK_YOU_MSG;
		// if($from_name==EMAIL_FROM_NAME)
			// $msg_note .=TEAM_MFB;
			// else
				// $msg_note .=$from_name;
				// $msg_note .='<br /><br />'.EMAIL_FOOTER2;
				// $msg_footer='</div><div style="background-color: #8BC34A;height: 15px;padding: 0px;text-align: center;font-weight: bold;">'.REG_NO.', MUTUAL FUND BAZAAR</div></div></div>';
				// $mail->Body = $msg_header.$message.$msg_note.$msg_footer;
				// if(!empty($FileAttachment)) {
					// $mail->AddAttachment($FileAttachment);
				// }
				// if($mail->Send())
					// return TRUE;
					// else
						// return FALSE;
	// }
}

?>