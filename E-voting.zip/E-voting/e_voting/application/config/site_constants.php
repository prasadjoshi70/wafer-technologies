<?php
//Base Url
define('BASE_URL','http://localhost/e_voting/');
//PROJECT NAME
define('EVOTING','E-Voting');
//SITE MENU's
define('M_MENU','E Voting');
define('M_HOME','Home');
define('M_REGISTER','Register');
define('M_INSTRUCTION','Instruction');
define('M_ABOUT_US','About Us');

define('M_SHOME','Home');
define('M_SINSTRUCTION','Instruction');
define('M_SAPPLY_FOR_POST','Apply For Post');
define('M_SCATE_VOTE','Cast Vote');
define('M_SRESULT','Result');
define('M_SLOGOUT','Logout');

define('M_DHOME','Home');

define('M_COURSE_URL','Add Course');
define('M_STUDENTLIST_URL','Student List');
define('M_CANDIDATE_URL','Candidate List');



//URL's
define('HOME_PAGE_URL','home');
define('INSTRUCTION_URL','instruction');
define('REGISTER_URL','register');
define('ABOUT_US_URL','about-us');
define('DOWNLOAD_PDF_PATH','uploads/instructions.pdf');
define('REGISTER_FORM','save-register');
define('LOGIN_FORM','login');
define('LOGOUT','logout');

define('S_HOME_PAGE_URL','student-home');
define('D_HOME_PAGE_URL','department-home');

define('S_STUDENTLIST_URL','student-list');
define('S_CANDIDATE_URL','candidate-list');
define('S_COURSE_URL','course');
define('S_POST_URL','post');
define('S_VOTE_URL','vote');
define('S_RESULT_URL','result');
define('S_COURSE_URL1','adminController/saveCourse');

define('S_EXPORT_LIST','export-student-list');
define('S_IMPORT_LIST','simport');
define('C_EXPORT_LIST','export-candidate-list');
define('C_IMPORT_LIST','cimport');




//PAGE TITLE
define('HOME','E-Voting | Home');
define('REGISTER','E-Voting | Register');
define('INSTRUCTION','E-Voting | Instruction');
define('ABOUT_US','E-Voting | About Us');

define('S_HOME','E-Voting | Student Home');
define('D_HOME','E-Voting | Department Home');
define('STUDENT_LIST','E-Voting | Student List');
define('CANDIDATE_LIST','E-Voting | Candidate List');
define('COURSE','E-Voting | Course');
define('POST','E-Voting | Apply for Post');
define('VOTE','E-Voting | Cast Vote');
define('RESULT','E-Voting | RESULT');
//OTHER CONSTANTS
define('ERROR_404','404 Page Not Found');
define('ERROR_MSG_404','Sorry! The page you\'re looking for cannot be found');