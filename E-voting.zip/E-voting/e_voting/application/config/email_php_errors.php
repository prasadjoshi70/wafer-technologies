<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// to enable, set this to true
$config['email_php_errors'] = TRUE;

$config['php_error_from'] = 'naiksiddhant335@gmail.com';
$config['php_error_to'] = 'naiksiddhant335@ymail.com';

// available shortcodes are {{severity}}, {{message}}, {{filepath}}, {{line}}
$config['php_error_subject'] = 'PHP Error';
$config['php_error_content'] = 'Severity: {{severity}} --> {{message}} File Path: {{filepath}} Line: {{line}}';

/* End of file email_php_errors.php */
/* Location: ./application/config/email_php_errors.php */