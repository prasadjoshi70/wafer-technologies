#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>

#define size 512
#define clen 128
#define hcnt 20        
#define FALSE 0
#define TRUE 1
#define STD_INPUT 0
#define STD_OUTPUT 1

struct command_t {
        char *name;
        int argc;
        char *argv[64];
};

struct command_t command;

        char cmd2[clen];
        char *hist[hcnt];
        int current = 0;

void history(char *hist[], int current)
{
        int i = current;
        int hnum = 1;
	
        do
	{
                if (hist[i])
		{
                        printf("%4d  %s\n", hnum, hist[i]);
                        hnum++;
                }
                i = (i + 1) % hcnt;
        } while (i != current);

}

void temp(char *hist[], int current)
{
        int hnum = 1;
if (command.argv[1] == NULL) 
{
history(hist,current);
}
else
{
int i,m;
m=command.argv[1][0]-48;
for (i=0;i<m;i++)
{
printf("%4d  %s\n", i, hist[i]);
}
}
}

void clear_history(char *hist[])
{
        int i;
        for (i = 0; i < hcnt; i++)
	{
                free(hist[i]);
                hist[i] = NULL;
        }
}



static char commandInput = '\0';
static int buf_chars = 0;
static char *pathv[64];
static char commandLine[80];

void printPrompt();
int readCommand(char *commandLine, char *commandInput);
int parseCommand(char *commandLine, struct command_t *command);
char * lookupPath(char **, char **);
void printPrompt();
int parsePath(char **);
void executePipedCommand(char **, char  **, char *, char *);


//function to clear screen
void cscreen() 
{
printf("\033[2J\033[1;1H");
}


void printPrompt() 
{
printf("myshell >> ");
}


//function to change the directory
void chDir() 
{
if (command.argv[1] == NULL) 
{
chdir(getenv("HOME"));
} 
else 
{
if (chdir(command.argv[1]) == -1) 
{
printf(" %s: no such directory\n",command.argv[1]);
}
}
}

//function to check the internal commnad ie cd, history and clear
int checkInternalCommand() 
{
if(strcmp("cd", command.argv[0]) == 0) 
{
chDir();
return 1;
}
else if (strcmp("history",command.argv[0]) == 0)
{
temp(hist,current);
return 1;
}
else if (strcmp("ch",command.argv[0]) == 0)
{
clear_history(hist);
return 1;
}
else if(strcmp("clear", command.argv[0]) == 0) 
{
cscreen();
return 1;
}
return 0;
}


// Function that will execute the command that is already builtin
int excuteCommand() 
{
int p;
int status;
pid_t cid;
p = fork();
if(p < 0 ) 
{
perror("Fork:");
return 1;
}
else if(p==0) 
{
execve(command.name, command.argv,0);
printf("Child process failed\n");
return 1;
}
else if(p > 0) 
{ 
wait(&status);
return 0;
}
}



// this function searches for * that is pipe

int processCommand() 
{
int i;
for(i=0;i<command.argc; i++) {
if(strcmp(command.argv[i], "*") == 0) 
{
return processPipedCommand(i);
}
}
return excuteCommand();
}


char * lookupPath(char **argv, char **dir) 
{
char *result;
char pName[96];

if( *argv[0] == '/') 
{
return argv[0];
}
else if( *argv[0] == '.') 
{
if(*++argv[0] == '.') 
{
if(getcwd(pName,sizeof(pName)) == NULL)
	perror("getcwd(): error\n");
else 
{
*--argv[0];
asprintf(&result,"%s%s%s",pName,"/",argv[0]);
}
return result;
}
*--argv[0];
if( *++argv[0] == '/') 
{
if(getcwd(pName,sizeof(pName)) == NULL)
	perror("getcwd(): error\n");
else 
{
asprintf(&result,"%s%s",pName,argv[0]);
}
return result;
}
}

// uses access() to see if the file is in the directory or not
	int i;
	for(i=0;i<64;i++) 
		{
		if(dir[i] != NULL) 
			{
			asprintf(&result,"%s%s%s", dir[i],"/",argv[0]);
			if(access(result, X_OK) == 0) 
			{
				return result;
			}
		}
		else continue;
	}
	fprintf(stderr, "%s: command not found\n", argv[0]);
	return NULL;
}

// this function populates "pathv" with environment variable PATH
int parsePath(char* dirs[])
{
int debug = 0;
char* pathEnvVar;
char* thePath;
int i;

for(i=0 ; i < 64 ; i++ )
	dirs[i] = NULL;
pathEnvVar = (char*) getenv("PATH");
thePath = (char*) malloc(strlen(pathEnvVar) + 1);
strcpy(thePath, pathEnvVar);

char* pch;
pch = strtok(thePath, ":");
int j=0;

while(pch != NULL) 
{
pch = strtok(NULL, ":");
dirs[j] = pch;
j++;
}
}


void executePipedCommand(char *argvA[], char  *argvB[], char * nameA, char * nameB) 
{
int pipefd[2];
int p;
if(pipe(pipefd)) 
{
perror("pipe");
exit(127);
}

p = fork();
if(p < 0 ) 
{
perror("Fork:");
}
else if(p==0) 
{
close(pipefd[0]);  
dup2(pipefd[1], 1);  
close(pipefd[1]); 
execve(nameA, argvA, 0);
perror(nameA);
exit(126);
}
else if(p > 0) 
{ 
close(pipefd[1]);  
dup2(pipefd[0], 0); 
close(pipefd[0]);  
execve(nameB, argvB, 0);
perror(nameB);
exit(125);
}
}


// this function parses commandLine into command.argv and command.argc
int parseCommand(char * commandLine, struct command_t * command) 
{
char * pch;
pch = strtok(commandLine," ");
int i=0;
while (pch != NULL) 
{
command->argv[i] = pch;
pch = strtok (NULL, " ");
i++;
}
command->argc = i;
command->argv[i++] = NULL;
return 0;
}

// this function read user input and save to commandLine
int readCommand(char * buffer, char * commandInput) 
{
buf_chars = 0;
while((*commandInput != '\n') && (buf_chars < 80)) 
{
buffer[buf_chars++] = *commandInput;
*commandInput = getchar();
}
buffer[buf_chars] = '\0';
strcpy(cmd2,commandLine);
return 0;
}

// this function will process the piped command
int processPipedCommand(int i) 
{
char *argvA[5];
char *argvB[5];
char *nameA, *nameB;
int ii;
for(ii=0;ii<i;ii++) 
{
argvA[ii] = command.argv[ii];
}
argvA[ii]=NULL;
nameA = lookupPath(argvA, pathv);
int j,jj=0;
for(j=i+1; j<command.argc; j++) 
{
argvB[jj] = command.argv[j];
jj++;
}
argvB[jj]=NULL;
nameB = lookupPath(argvB, pathv);
int p,status;
fflush(stdout);
p=fork();
if(p < 0 ) 
{
perror("Fork:");
}
else if(p==0) 
{
executePipedCommand(argvA, argvB, nameA, nameB);
}
else if(p > 0) 
{ 
p=wait(&status);
return 0;
}
return 1;
}

int main(int argc, char* argv[]) 
{
int i;
int debug = 0;
parsePath(pathv);

while(TRUE) 
{
printPrompt();

commandInput=getchar(); //gets 1st char
if(commandInput == '\n') 
{ 
continue;
}
else 
{
readCommand(commandLine, &commandInput); // read command

if((strcmp(commandLine, "exit") == 0) || (strcmp(commandLine, "quit") == 0))
break;
parseCommand(commandLine, &command); //parses command into argv[], argc

if(checkInternalCommand() == 0) 
{
command.name = lookupPath(command.argv, pathv);
if(command.name == NULL) {
printf("Usage: \n");
continue;
}
processCommand();
}

		if (cmd2[strlen(cmd2) - 1] == '\n')
                        cmd2[strlen(cmd2) - 1] = '\0';
		free(hist[current]);
		hist[current] = strdup(cmd2);
		current = (current + 1) % hcnt;
}
}
printf("\n");
exit(EXIT_SUCCESS);
}


