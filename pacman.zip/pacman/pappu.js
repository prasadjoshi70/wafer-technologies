"use strict";

//key code
var keyleft=37;
var keyup=38;
var keyright=39;
var keydown1=40;

//variable declaration
var run=10;  
var d=30;   
var grid=20;
var rowlast=570;
var collast=570;
var score=0;
var leftm=0;
var topm=0;
var fittop=0;
var fitleft=0;
var prow=0;
var pcol=0;
var type;
var direction,start;
var pacman;
var arr=[];
var mon1;
var mon2;
var mon3;
var mon4;
var starttime;
var clock=0;
var newtop,newleft,extratop,extraleft;
var flag=false;
var timer;
var isdead1=false;
var isdead2=false;
var isdead3=false;
var isdead4=false;
var stop;

//audio for food and death
var audio1=new Audio('death.wav');
var audio=new Audio('eatfruit.wav');

//function for creating an object
function create(type,leftm,topm,direction,starttime)
{
  this.type=type;
  this.leftm=leftm;
  this.topm=topm;
  this.direction=direction;
  this.starttime=starttime;
  this.arr=[0,0,0,0];
  this.start=false;
}

//function for declaring pacman and monster
function createmon()
{
	pacman=new create("ima",270,30,0,0);
	mon1=new create("mon1",330,240,keydown1,4000);
    mon2=new create("mon2",360,240,keydown1,3000);
	mon3=new create("mon3",330,270,keyright,2000);
	mon4=new create("mon4",360,270,keyright,1000);
	
}

//grid of 30 by 30
var matrix = [[1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1],
			  [1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,1],
			  [1,0,1,1,1,0,1,1,1,0,1,1,0,1,1,1,1,1,0,1],
		      [1,0,0,0,0,0,1,1,1,0,1,1,0,0,0,0,0,0,0,1],
			  [1,0,1,1,1,0,0,0,0,0,1,1,0,1,1,1,1,1,0,1],
			  [1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1],
			  [1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,0,1,0,1],
		      [1,0,1,1,1,1,1,0,1,0,1,1,1,1,0,1,0,1,0,1],
		      [1,0,0,0,0,0,0,0,1,0,1,3,3,1,0,1,0,1,0,1],
			  [1,0,1,0,1,1,1,0,1,0,1,3,3,3,0,1,0,1,0,1],
			  [1,0,0,0,1,1,1,0,1,0,1,1,1,1,0,1,0,1,0,1],
			  [2,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2],
			  [1,0,1,0,1,1,0,1,0,1,0,1,0,1,1,1,1,1,0,1],
		      [1,0,1,0,1,1,0,1,0,1,0,1,0,0,0,0,0,0,0,1],
			  [1,0,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,1],
			  [1,0,1,1,1,1,1,0,1,0,0,1,0,0,0,0,0,0,0,1],
			  [1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,1,1,0,1],
		      [1,0,1,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,0,1],
		      [1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,1],
			  [1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1]];

			  
// function of creating grid at onload i.e when game starts			
function obstacle()
{			 
var main=document.getElementById("container");
			 
for(var i=0; i < matrix.length; i++) 
{
    for(var j=0; j < matrix.length; j++) 
	{
		var ddiv=document.createElement("div");
		ddiv.id="R"+i+"C"+j;
		ddiv.style.width="30px";
		ddiv.style.height="30px";	
		ddiv.style.float="left";
		ddiv.style.border="1px solid black";
		ddiv.style.boxSizing="border-box";	
	
		if(matrix[i][j]==1)
		{
			ddiv.style.backgroundImage="url('briks.jpg')";
		}
		else if(matrix[i][j]==2)
		{
			ddiv.style.backgroundImage="";
		}
		else if(matrix[i][j]==3 )
		{
			ddiv.style.backgroundColor="Lightblue";
		}
		else if(matrix[i][j]==4 )
		{
			ddiv.style.backgroundImage="url('pp.png')";
		}
		else	
		{
			ddiv.style.backgroundImage="url('low-dot.jpg')";
		}
		main.appendChild(ddiv);
    }
}
createmon();
document.addEventListener('keydown',press,true);
}

//function of making super monsters
function time()
{
	if((matrix[newtop][newleft]==4) || (matrix[extratop][extraleft]==4))
	{
		document.getElementById("ima").style.filter="invert(100%)";
		matrix[newtop][newleft]=2;
		flag = true;
		timer = 4000;
	}
	
}

//function for moving pacman
function move(actor)
{	
	if(document.getElementById("R"+prow+"C"+pcol).style.backgroundImage)
	{
		score=score + 5;
		audio.play();
	}
	document.getElementById("sc").innerHTML=score;

	if(score == 955)
	{
	document.getElementById("win").style.display="block";
	clearInterval(stop);
	}

	time();

	switch(actor.direction)
	{
		case keydown1:
			document.getElementById(actor.type).style.transform="rotate(90deg)";
			document.getElementById("R"+prow+"C"+pcol).style.backgroundImage="";
			actor.topm = actor.topm + run;
			document.getElementById(actor.type).style.top = actor.topm + 'px';
			if(actor.topm >= rowlast)
			{
				actor.topm = 0;
			}
		break;

		case keyup:
			document.getElementById(actor.type).style.transform="rotate(270deg)";
			document.getElementById("R"+prow+"C"+pcol).style.backgroundImage="";	
			actor.topm = actor.topm - run;
			document.getElementById(actor.type).style.top = actor.topm + 'px';
			if(actor.topm <= 0)
			{
				actor.topm = (grid - 1)*d;
			}   
		break;
	
		case keyright:
			document.getElementById(actor.type).style.transform="rotate(360deg)";
			document.getElementById("R"+prow+"C"+pcol).style.backgroundImage="";
			actor.leftm = actor.leftm + run;
			document.getElementById(actor.type).style.left = actor.leftm + 'px';
			if(actor.leftm >= collast)
			{
				actor.leftm = 0;
			}
		break;
	
		case keyleft:
			document.getElementById(actor.type).style.transform="rotate(180deg) rotateX(180deg)";
			document.getElementById("R"+prow+"C"+pcol).style.backgroundImage="";
			actor.leftm = actor.leftm - run;
			document.getElementById(actor.type).style.left = actor.leftm + 'px';
			if(actor.leftm <= 0)
			{
				actor.leftm= (grid - 1)*d;
			}
		break;
	
	}
}

//function for event listener
function press(event)
{
	pacman.direction=event.keyCode;
	
	if(pacman.start==false)
	{
		pacman.start=true;
		stop=setInterval(fun,100);
	}
}

//function for setting the time for monster move out
function fun()
{
	var k;
	clock = clock + 100;
	
	if(!canmove(pacman))
	{
		move(pacman);
	}
			
	if(clock > mon4.starttime)
	{
		moveMonster(mon4);	
	}
		
	if(clock > mon3.starttime)
	{
		moveMonster(mon3);	
	}
		
	if(clock > mon2.starttime)
	{
		moveMonster(mon2);	
	}
		
	if(clock > mon1.starttime)
	{
		moveMonster(mon1);	
	}
		
	if(clock > 5500)
	{
		matrix[9][13]=1;
		clock = 5500;
	}
		
	if(flag==true)
	{
	timer = timer - 100;
	}

	if(timer < 0)
	{
		document.getElementById("ima").style.filter="invert(0%)";
		flag=false;
	}
	
	if(checkIntersect(pacman,mon4))
	{
		if(isdead1==false)
		{
			if(flag==true)
			{
				document.getElementById("mon4").style.display="none";
				isdead1=true;
			}
			else
			{
				audio1.play();
				document.getElementById("ima").style.display="none";
				document.getElementById("loose").style.display="block";
				clearInterval(stop);
			}
		}
	}
	
	if(checkIntersect(pacman,mon3))
	{
		if(isdead2==false)
		{
			if(flag==true)
			{
				document.getElementById("mon3").style.display="none";
				isdead2=true;
			}
			else
			{
				audio1.play();
				document.getElementById("ima").style.display="none";
				document.getElementById("loose").style.display="block";
				clearInterval(stop);
			}
		}
	}
	
	if(checkIntersect(pacman,mon2))
	{
		if(isdead3==false)
		{
			if(flag==true)
			{
				document.getElementById("mon2").style.display="none";	
				isdead3=true;
			}
			else
			{
				audio1.play();
				document.getElementById("ima").style.display="none";
				document.getElementById("loose").style.display="block";
				clearInterval(stop);
			}
		}
	}
	
	if(checkIntersect(pacman,mon1))
	{
		if(isdead4==false)
		{
			if(flag==true)
			{
				document.getElementById("mon1").style.display="none";
				isdead4=true;
			}
			else
			{
				audio1.play();
				document.getElementById("ima").style.display="none";
				document.getElementById("loose").style.display="block";
				clearInterval(stop);
			}
		}
	}
	
	collideMon();
	
}

//function for intersecting a monster
function collideMon()
{
if(checkIntersect(mon1,mon2))
	{
		opposite(mon1);
		opposite(mon2);
	}
	
	if(checkIntersect(mon1,mon3))
	{
		opposite(mon1);
		opposite(mon3);
	}
	
	if(checkIntersect(mon1,mon4))
	{
		opposite(mon1);
		opposite(mon4);
	}
	
	if(checkIntersect(mon2,mon3))
	{
		opposite(mon2);
		opposite(mon3);
	}
	
	if(checkIntersect(mon2,mon4))
	{
		opposite(mon2);
		opposite(mon4);
	}
	
	if(checkIntersect(mon3,mon4))
	{
		opposite(mon3);
		opposite(mon4);
	}	
}


//function for checking the obstacle or not
function canmove(actor)
{
	var rowlast = 570;
	var collast = 570;
	var overlapCol=false;
	var overlapRow=false;
	var fitCol=false;
	var fitRow=false;
	
	fittop=actor.topm % d;
	fitleft=actor.leftm % d;
	prow=Math.floor(actor.topm / d);
	pcol=Math.floor(actor.leftm / d);
	
	if(fittop != 0)
	{
		overlapRow=true;
	}
	
	if(fitleft != 0)
	{
		overlapCol=true;
	}
	
	if(fittop == 0)
	{
		fitRow=true;
	}
	
	if(fitleft == 0)
	{
		fitCol=true;
	}
	
	newtop=prow;
	newleft=pcol;
	
	switch(actor.direction)
	{			
		case keydown1:
			newtop=newtop + 1;
		break;
			
		case keyup: 
			if(fitRow)
			{
				newtop=newtop - 1;
			}
		break;
			
		case keyright:
			newleft=newleft + 1;
		break;
			
		case keyleft:
			if(fitCol)
			{
				newleft=newleft - 1;
			}
		break;
	}
	
	
	extratop=newtop;
	extraleft=newleft;
	
	
	switch(actor.direction)
	{
		case keyup: 
		case keydown1:
			if(overlapCol)
			{
				extraleft = newleft + 1;
			}
		break;
		
		case keyright: 
		case keyleft: 
			if(overlapRow)
			{
				extratop = newtop + 1;
			}
		break;
	}
	
	if(extratop > rowlast)
	{
		extratop = rowlast;
	}
	
	if(extraleft > collast)
	{
		extraleft = collast;
	}
	
	
	if((matrix[newtop][newleft]==1) || (matrix[extratop][extraleft]==1))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//function for moving the monster
function moveMon(actor)
{	
//console.log(actor.type);
//console.log(actor.direction);
	switch(actor.direction)
	{
		case keydown1:
			actor.topm = actor.topm + run;
			document.getElementById(actor.type).style.top = actor.topm + 'px';
			if(actor.topm >= rowlast)
			{
				actor.topm = 0;
			}
		break;

		case keyup:
			actor.topm = actor.topm - run;
			document.getElementById(actor.type).style.top = actor.topm + 'px';
			if(actor.topm <= 0)
			{
				actor.topm = (grid - 1)*d;
			}   
		break;
	
		case keyright:
			actor.leftm = actor.leftm + run;
			document.getElementById(actor.type).style.left = actor.leftm + 'px';
			if(actor.leftm >= collast)
			{
				actor.leftm = 0;
			}
		break;
	
		case keyleft:
			actor.leftm = actor.leftm - run;
			document.getElementById(actor.type).style.left = actor.leftm + 'px';
			if(actor.leftm <= 0)
			{
				actor.leftm = (grid - 1)*d;
			}
		break;	
	}
}


//function to check whether the monster can move
function canmoveMon(actor)
{
	var k;
  //console.log(actor.direction);
	switch(actor.direction)
	{
		case keyup:
			actor.arr=[keyup,keyright,keyleft,keydown1];
		break;
			
		case keydown1:
			actor.arr=[keydown1,keyright,keyleft,keyup];
		break;
			
		case keyright:
			actor.arr=[keyright,keyup,keydown1,keyleft];
		break;
			
		case keyleft:
			actor.arr=[keyleft,keyup,keydown1,keyright];
		break;
    }
  
    shuffle(actor);
    //console.log(actor.arr[0]+" "+actor.arr[1]+" "+actor.arr[2]+" "+actor.arr[3]);
	
	for(k=0; k<actor.arr.length;k++)
	{
		//console.log(actor.arr[k]);
		actor.direction=actor.arr[k];
		//console.log(canmove(actor));
		if(!canmove(actor))
		{
			//console.log(actor.direction);
			moveMon(actor);
			break;
		} 	  
	}
}

//function to move monster in opposite direction when they intersect each other
function opposite(actor)
{
	var k;
  //console.log(actor.direction);
	switch(actor.direction)
	{
		case keyup:
			actor.arr=[keydown1,keyright,keyleft,keyup];
		break;
			
		case keydown1:
			actor.arr=[keyup,keyright,keyleft,keydown1];
		break;
			
		case keyright:
			actor.arr=[keyleft,keyup,keydown1,keyright];
		break;
			
		case keyleft:
			actor.arr=[keyright,keyup,keydown1,keyleft];
		break;
	}
  
  shuffle(actor);
  //console.log(actor.arr[0]+" "+actor.arr[1]+" "+actor.arr[2]+" "+actor.arr[3]);
  
  for(k=0; k<actor.arr.length;k++)
  {
	//console.log(actor.arr[k]);
	actor.direction=actor.arr[k];
	//console.log(canmove(actor));
	if(!canmove(actor))
	{
		//console.log(actor.direction);
		moveMon(actor);
		break;
	} 	  
  }
}


//function to shuffle the direction
function shuffle(actor)
{
	var m=actor.arr.length-1;
	var t,i;
  
	while(m)
	{
		i=Math.floor(Math.random() * m--);
		//console.log(i +" "+m);
		t=actor.arr[m];
		actor.arr[m]=actor.arr[i];
		actor.arr[i]=t;
	}	
}

var count1=0,count2=0;
var count3=0,count4=0;
var count5=0,count6=0;

//function to initially come monster out of gate and then move randomly
function moveMonster(actor)
{
	switch(actor.type)
	{
		case "mon4":
			if(count1++ < 2)
			{
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else
			{
				canmoveMon(actor);
			}
		break;
	
		case "mon3":
			if(count2++ < 4)
			{
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else
			{
				canmoveMon(actor);
			}
		break;
	
		case "mon2":
			if(count3++ < 3)
			{
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else if(count4++ < 2)
			{
				actor.direction=keyright;
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else
				{
					canmoveMon(actor);
				}
		break;
	
		case "mon1":
			if(count5++ < 6)
			{
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else if(count6++ < 4)
			{
				actor.direction=keyright;
				if(!canmove(actor))
				{
					moveMon(actor);
				}	
			}
			else
				{
					canmoveMon(actor);
				}
		break;
}
}

//function to check whether the actor are intersecting or not
function checkIntersect(actor1,actor2) 
{
	//alert(actor1.type);
	//alert(actor2.type);
	if (actor1.leftm >= (actor2.leftm+d) || actor2.leftm >= (actor1.leftm+d) || actor1.topm >= (actor2.topm+d) || actor2.topm >= (actor1.topm+d))
	{
		return false;
	}
	else
	{	
		return true;
	}
}	