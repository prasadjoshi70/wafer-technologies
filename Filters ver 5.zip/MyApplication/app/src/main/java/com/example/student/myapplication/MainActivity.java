package com.example.student.myapplication;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Random;

public class MainActivity extends Activity {
    private ImageView imageview ;
    private static final int GALLERY = 100;
    private Bitmap src;
    private Button saveimage, shareimage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageview = (ImageView) findViewById(R.id.imgview);
        saveimage= (Button) findViewById(R.id.save);
        shareimage= (Button) findViewById(R.id.share);
        src = BitmapFactory.decodeResource(getResources(), R.drawable.test);
        imageview.setDrawingCacheEnabled(true);
        imageview.buildDrawingCache();

        shareimage.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){

                Bitmap bitmap;
                OutputStream output;
                // Retrieve the image from the res folder
                bitmap = imageview.getDrawingCache();
                // Find the SD Card path
                File filepath = Environment.getExternalStorageDirectory();
                // Create a new folder AndroidBegin in SD Card
                File dir = new File(filepath.getAbsolutePath() + "/Share Image Tutorial/");
                dir.mkdirs();
                //Create a name for the saved image
                File file = new File(dir, "sample_wallpaper.png");
                try {
                    // Share Intent
                    Intent share = new Intent(Intent.ACTION_SEND);
                    // Type of file to share
                    share.setType("image/jpeg");
                    output = new FileOutputStream(file);
                    // Compress into png format image from 0% - 100%
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
                    output.flush();
                    output.close();
                    // Locate the image to Share
                    Uri uri = Uri.fromFile(file);
                    // Pass the image into an Intnet
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    // Show the social share chooser list
                    startActivity(Intent.createChooser(share, "Share Image Tutorial"));
                    imageview.destroyDrawingCache();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });
    }

    public void buttonClicked(View v){
        Toast.makeText(this,"Please wait",Toast.LENGTH_SHORT).show();
        Grey g = new Grey();
        Emboss em=new Emboss();
        Reddish r=new Reddish();
        Engrave en=new Engrave();
        Flip f=new Flip();
        Sharpen sh=new Sharpen();

        if(v.getId() == R.id.pick){
            selectPicture(v);
        }
        else if(v.getId() == R.id.grey)
            imageview.setImageBitmap(g.getGrayscale(src));
        else if(v.getId() == R.id.emboss_effect)
            imageview.setImageBitmap(em.EmbossEffect(src));
        else if(v.getId() == R.id.reddish_eff)
            imageview.setImageBitmap(r.ReddishEffect(src));
        else if(v.getId() == R.id.engrave_eff)
            imageview.setImageBitmap(en.EngraveEffect(src));
        else if(v.getId() == R.id.vertical)
            imageview.setImageBitmap(f.flipVertically(src));
        else if(v.getId() == R.id.horizontal)
            imageview.setImageBitmap(f.flipHorizontally(src));
        else if(v.getId() == R.id.sharpen_eff)
            imageview.setImageBitmap(sh.SharpenEffect(src, 100));
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        switch(code) {
            case GALLERY:
                if(result == RESULT_OK){
                    Uri selectedImage = data.getData();
                    Bitmap bmp;
                    bmp = decodeUri(selectedImage);
                    if(bmp !=null){
                        src = bmp;
                        imageview.setImageBitmap(src);
                    }
                }
        }
    }

    private Bitmap decodeUri(Uri selectedImage)  {
        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);

            // The new size we want to scale to
            final int size = 400;

            // Find the correct scale value. It should be the power of 2.
            int width = o.outWidth;
            int height = o.outHeight;
            int scale = 1;
            while (true) {
                if (width / 2 < size || height / 2 < size) {
                    break;
                }
                width /= 2;
                height /= 2;
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o2);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public void saveImg(View view) {
        Bitmap bitmap = imageview.getDrawingCache();
        String root = Environment.getExternalStorageDirectory().toString();
        File newDir = new File(root + "/Pictures");
        newDir.mkdirs();
        Random gen = new Random();
        int n = 10000;
        n = gen.nextInt(n);
        String photoname = "DCIM_"+n+".jpg";

        try {
            FileOutputStream out = new FileOutputStream(root +"/Pictures/"+ photoname);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            Toast.makeText(getApplicationContext(), "Photo Saved "+ photoname,Toast.LENGTH_SHORT).show();
            out.close();
        } catch (Exception e) {
            Log.e("Exception", e.toString());
        }
        imageview.destroyDrawingCache();
    }

    public void selectPicture(View view) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 19);
        } else {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryIntent.setType("image/*");
            startActivityForResult(galleryIntent, GALLERY);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 19: {
                if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    //Log.i(TAG, "Permission has been denied by user");
                } else {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, GALLERY);
                    //Log.i(TAG, "Permission has been granted by user");
                }
                return;
            }
            default:
                break;
        }
    }


}

