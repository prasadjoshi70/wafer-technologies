package com.example.student.myapplication;

import android.graphics.Bitmap;

/**
 * Created by Student on 26-11-2017.
 */

public class Emboss {

    public static Bitmap EmbossEffect(Bitmap src) {
        double[][] Emboss = new double[][] {
                { -1 ,  0, -1 },
                {  0 ,  4,  0 },
                { -1 ,  0, -1 }
        };
        Filtersmatrix matrix = new Filtersmatrix(3);
        matrix.applyConfig(Emboss);
        matrix.Factor = 1;
        matrix.Offset = 127;
        return Filtersmatrix.compute(src, matrix);
    }
}
