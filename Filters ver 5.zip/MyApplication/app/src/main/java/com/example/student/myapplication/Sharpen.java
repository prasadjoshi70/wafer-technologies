package com.example.student.myapplication;

import android.graphics.Bitmap;

/**
 * Created by Student on 26-11-2017.
 */

public class Sharpen {

    public Bitmap SharpenEffect(Bitmap src, double weight) {
        double[][] SharpConfig = new double[][] {
                { 0 , -2    , 0  },
                { -2, weight, -2 },
                { 0 , -2    , 0  }
        };
        Filtersmatrix matrix = new Filtersmatrix(3);
        matrix.applyConfig(SharpConfig);
        matrix.Factor = weight - 8;
        return Filtersmatrix.compute(src, matrix);
    }
}
