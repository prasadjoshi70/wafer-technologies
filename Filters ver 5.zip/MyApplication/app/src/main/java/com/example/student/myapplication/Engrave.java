package com.example.student.myapplication;

import android.graphics.Bitmap;

/**
 * Created by Student on 26-11-2017.
 */

public class Engrave {
    public Bitmap EngraveEffect(Bitmap src) {
        Filtersmatrix matrix = new Filtersmatrix(3);
        //matrix.setAll(0);
        matrix.Matrix[0][0] = -2;
        matrix.Matrix[1][1] = 2;
        matrix.Factor = 1;
        matrix.Offset = 95;
        return Filtersmatrix.compute(src, matrix);
    }
}
