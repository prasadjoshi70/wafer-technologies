<!--!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
//adding of instructor id remaining

	include "conn.php";
	$query="select * from exam" ;
	$result=oci_parse($connection,$query);
	oci_execute($result);
	if(isset($_POST['submit']) && ($_SERVER["REQUEST_METHOD"] == "POST"))
	{
		$question=$_POST['question'];
		$instructorid=1;
		$examname=$_POST['examname'];
		$marks=$_POST['marks'];
		$negative=$_POST['negative'];
		$level=$_POST['level'];
		$category=$_POST['category'];
		$answer=$_POST['answer'];
		$option1=$_POST['option1'];
		$option2=$_POST['option2'];
		$option3=$_POST['option3'];
		$option4=$_POST['option4'];
		$examtype=$_POST['examtype'];
		$query2="select * from exam where ='$examname'" ;
		$result2=oci_parse($connection,$query2);
		oci_execute($result2);
		while(($row=oci_fetch_array($result2, OCI_BOTH))){
		 $examdate=$row['EXAM_DATE'];
		 //echo "'$'"
		}
		$sql1 = "insert into QUESTIONGENERATOR(CATEGORY,INSTRUCTOR_ID,TYPE,EXAM_NAME,EXAM_DATE,QUESTION_NO,QUESTIONS,ANSWER,OPTION_1,OPTION_2,OPTION_3,OPTION_4,MARKS,NEGATIVE_MARKS)values('$category','$instructorid','$examtype','$examname',To_date('$examdate','yyyy-mm-dd'),question_no.nextval,'$question','$answer','$option1','$option2','$option3','$option4','$marks','$negative')";
			
			$result1 = oci_parse($connection, $sql1);
			oci_execute($result1);
			$RowsAffected=oci_num_rows($result1);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('Registration done in Successfully')</script>";
			
			}
	}
			
	
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>ADD QUESTIONS</h1>
        </div>

        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <div class="contact-form">
              <label><h1> <span>Question:</span></h1>
                 <textarea name="question" id="textarea" class="input_text" required="required"></textarea>
              </label>
              <br>
			  <label><h1> <span>Exam Name</span></h1>
			  <select name="examname">
				 <?php while(($row=oci_fetch_array($result, OCI_BOTH))){?>
				 <option><?php echo $row['EXAM_NAME'];?></option>
				 <?php }?>
			  </select>
              <label>
			  <br/><br>
              MARKS:
              <select name="marks" id="select">
				<option> mark</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
              NEGATIVE:
              <select name="negative" id="select1">
			  <option>select neg mark</option>
                <option value="1">1</option>
                <option value="2">2</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
              LEVEL:
              <select name="level" id="select3">
				<option>select level</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
			  <br><br>
			  
              Category:
              <select name="category" id="select4">
				<option>Select category</option>
                <option>Aptitude</option>
                <option>General Knowlege</option>
                <option>Computer Awarness</option>
				<option>Logical Reasoning</option>
				<option>Mathematics</option>
				<option>Physics</option>
				<option>Chemistry</option>
				<option>Civil Engineering</option>
				<option>Life Science</option>
				<option>Engineering Science</option>
              </select>
            </label>
              <br>
              <label><h1> <span>Options:</span></h1></label>
              <br>
              <label>
              <input name="answer" type="radio" value="radiobutton" id="radio1" />
              <input name="option1" type="text" id="option1" maxlength="100" class="input_text" />
              </label>

             <label>
              <input name="answer" type="radio" value="radiobutton" id="radio2" />
              <input name="option2" type="text" id="option2" maxlength="100" class="input_text" />
             </label>

 
            <label>
            <input name="answer" type="radio" value="radiobutton" id="radio3" />
             <input name="option3" type="text" id="option3" maxlength="100" class="input_text" />
            </label>

			<label>
            <input name="answer" type="radio" value="radiobutton" id="radio4" />
            <input name="option4" type="text" id="option4" maxlength="100" class="input_text"/>
            </label> 
            <br>
            <label> EXAM TYPE: </label>
            <label>
            <input type="radio" name="examtype" id="checkbox" />
             PRELIMINARY</label> 
             <label>
             <input type="radio" name="examtype" id="checkbox2" />
             MAIN</label>
             
             
             <div>
            <input type="submit" class="button" value="ADD" />
            <!--input type="submit" class="button" value="OK" /-->
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
