<?php

$user="test";
$pass="test";
$connection=oci_connect($user, $pass, 'localhost/XE');
if (!$connection) {
	
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

?>