<?php
	include "conn.php";
	 $id1=$_REQUEST['id'];
	 $sql = "delete from organisation where ORGAN_ID = $id1";
			
			$result = oci_parse($connection, $sql);
			oci_execute($result);
			  echo "<script type='text/javascript'>window.alert('Record Deleted Successfully')
						window.location='manage_organisation.php';</script>";
		  
?>