<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
include "conn.php";
?>
	 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>EDIT INSTRUCTOR</h1>
        </div>
        <div class="content">
		 
        </div>
      </div>
    </div>
  </div>
</div>

<?php
//aid=$row['INSTRUCTOR_ID
			if((isset($_POST['update']) &&( $_SERVER["REQUEST_METHOD"] == "POST"))){
			 $id1=$_POST['id'];
			 $name1=$_POST['name'];
			 $add1=$_POST['address'];
			 $email1=$_POST['email'];
			 $phone1=$_POST['child_1'];
			 $unidet1=$_POST['Uni_details'];
			 $degree1=$_POST['degree'];
			 $noqest1=$_POST['noquestion'];
			//$query="UPDATE instructor SET FULL_NAME='$_POST['name']',ADDRESS='$_POST['address']',EMAIL='$_POST['email'] ',PHONE='$_POST['child_1']',UNIDET='$_POST['Uni_details']',DEGREE='$_POST['degree']',NO_OF_QUESTIONS_PROVIDED='$_POST['noquestion']' where INSTRUCTOR_ID='.$id1.'";

		$query="UPDATE instructor SET FULL_NAME='$name1',ADDRESS='$add1',EMAIL='$email1' ,PHONE='$phone1',UNIDET='$unidet1',DEGREE='$degree1',NO_OF_QUESTIONS_PROVIDED='$noqest1' where INSTRUCTOR_ID='$id1'";
			$result=oci_parse($connection,$query);
		  oci_execute($result);
		  $RowsAffected=oci_num_rows($result);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('Update done Successfully')
						window.location='manage_instructor.php';</script>";
			
			}
			}
?>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
