<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->

<?php
	

	if(isset($_POST['register']) && ($_SERVER["REQUEST_METHOD"] == "POST"))
	{
		$count1=$_POST['count'];
		/*echo '<script type="text/javascript">alert("'.$count1.'");</script>';
        echo "<script language='javascript' type='text/javascript'> alert('Recorded Successfully'); </script>";*/
		
		$fname=$_POST['fname'];
		$middlename=$_POST['middlename'];
		$lname=$_POST['lname'];
		$child_1=$_POST['child_1'];
		$email=$_POST['email'];
		$dob=$_POST['dob'];
		$pid=$_POST['pid'];
		$caste=$_POST['caste'];
		$stno=$_POST['stno'];
		$stname=$_POST['stname'];
		$aptno=$_POST['aptno'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$pincode=$_POST['pincode'];
		$payment='0';
		
		
		$image=file_get_contents($_FILES['photo']['tmp_name']);
		//$image_name=addslashes($_FILES['photo']['name']);
		$image_size = getimagesize($_FILES['photo']['tmp_name']);
		$image1=file_get_contents($_FILES['sign']['tmp_name']);
		//$image_name1=addslashes($_FILES['sign']['name']);
		$image_size1 = getimagesize($_FILES['sign']['tmp_name']);
		$image2=file_get_contents($_FILES['castecert']['tmp_name']);
		//$image_name2=addslashes($_FILES['castecert']['name']);
		$image_size2 = getimagesize($_FILES['castecert']['tmp_name']);
		if($image_size==FALSE )
		{
			echo "that's  not an image";
		}   
		else
		{
			include "conn.php"; 
			echo $sql = "INSERT INTO person(person_id,fname,mname,lname,street_no,street_name,apt_name,city,caste,state,pincode,phone,email,payment,dob,photo,sign,cpic)values(person_sequence.nextval,'$fname','$middlename','$lname','$stno','$stname','$aptno','$city','$caste','$state','$pincode','$child_1','$email','$payment',To_date('$dob','yyyy-mm-dd'),empty_blob(),empty_blob(),empty_blob())RETURNING photo,sign,cpic INTO :image,:image1,:image2";
			$result = oci_parse($connection, $sql);
			$blob = oci_new_descriptor($connection, OCI_D_LOB);
			oci_bind_by_name($result, ":image", $blob, -1, OCI_B_BLOB);
			oci_bind_by_name($result, ":image1", $blob, -1, OCI_B_BLOB);
			oci_bind_by_name($result, ":image2", $blob, -1, OCI_B_BLOB);
			oci_execute($result, OCI_DEFAULT) or die ("Unable to execute query");

			if(!$blob->save($image)) {
				oci_rollback($connection);
		}
		else {
				oci_commit($connection);
		}

			oci_free_statement($result);
			$blob->free();
			
			
			//qualification insert
			for($i=1;$i < 4;$i++){
			$degree=$_POST['degree_'.$i];
			$board=$_POST['board_'.$i];
		    $course=$_POST['course_'.$i];
		    $percentage=$_POST['percentage_'.$i];
			
			$sql1 = "insert into Qualification(qes_no,person_id,degree,percentage,board,stream)values(quali_sequence.nextval,person_sequence.currval,'$degree','$percentage','$board','$course')";
			
			$result1 = oci_parse($connection, $sql1);
			oci_execute($result1);
			$RowsAffected=oci_num_rows($result1);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('Registration done in Successfully')
						window.location='mail.php';</script>";
			
			}
			}
			
		}
	}
	
	//oci_execute($q);
	
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
<!-- script for phone number-->
<script type="text/javascript">
function change(obj) {


    var selectBox = obj;
    var selected = selectBox.options[selectBox.selectedIndex].value;
    var cert = document.getElementById("castecert");
	var cst = document.getElementById("cst");

    if(selected != 'General'){
        cert.style.display = "block";
		cst.style.display = "block";
    }
    else{
        cert.style.display = "none";
		cst.style.display = "none";
    }
}
</script>

<!-- script for Qualification-->
<script type="text/javascript">
var i = 1;
var limit = 2;
counter=0;
function addquali(){
	if (i == limit){
		alert("You have reached the limit of adding " + i-1);
     }
	else {	
		
    	var newdiv = document.createElement('div');
		//div.style.width = "100px";
		newdiv.style.height = "50px";
		newdiv.style.color = "white";
		
		//div.setAttribute('class', 'myclass');
    	newdiv.innerHTML ='<input type="text" name="degree_4" class="input_text" id="degree_4" required style="width:100px;" value="PG" readonly />&nbsp;<input type="text" name="board_4" id="board_4" class="input_text" required style="width:140px;"  placeholder="Board/University"/>&nbsp;<input type="text" name="course_4" class="input_text" id="course_4" required style="width:150px;"  placeholder="Stream/Specilization"/>&nbsp;<input type="text" name="percentage_4" class="input_text" id="percentage_4" required style="width:100px;"  placeholder="Percentage"/><input type="button" id="add" onClick="addquali()" value="+" class="add-button" /><input type="button" value="-" onclick="removequali(this)" class="add-button" />';

    	document.getElementById('quali').appendChild(newdiv);
		i++;
		
	}
	counter=i;
	document.getElementById('count').value=counter;
	
}

function removequali(div) {	
    document.getElementById('quali').removeChild( div.parentNode );
	i--;
}
</script>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Student registration</h1>
        </div>
        <div class="content">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
            <div class="contact-form">
                
                
               <h1>Personal Details:</h1>
              <label> <span>Firstname:</span>
			    <input type="hidden" name="count" id="count" />
                <input type="hidden" name="pid" id="pid" value="18951" />
                <input type="text" class="input_text" name="fname" id="fname" required/>
              </label>
              <label> <span>Middlename:</span>
                <input type="text" class="input_text" name="middlename" id="mname" required/>
              </label>
              <label> <span>Lastname:</span>
                <input type="text" class="input_text" name="lname" id="lname" required/>
              </label>
              <label><span>Phone No.:</span>
                <input name="child_1" type="text" id="child_1" class="input_text" required />
              </label>
              <label> <span>Email:</span>
                <input type="email" class="input_text" name="email" id="email" required/>
              </label>
              <label> <span>Date Of Birth:</span>
                <input type="date" class="input_text" name="dob" id="dob" min="1966-01-01" max="1995-12-31" required/>
              </label>
              <label> <span>Caste:</span>
              <select name="caste" id="show" class="input_text" onChange="change(this)">
				<option value="">select category</option>
                <option value="General">GEN</option>
                <option value="SC">SC</option>
                <option value="ST">ST</option>
                <option value="OBC">OBC</option>

              </select>
              </label>
              <br>
               <h1>Address</h1>
              <label> <span>Street No:</span>
                <input type="text" class="input_text" name="stno" id="streetno" required/>
              </label>
              <label> <span>Street Name:</span>
                <input type="text" class="input_text" name="stname" id="streetname" required/>
              </label>
              <label> <span>Apt No:</span>
                <input type="text" class="input_text" name="aptno" id="aptno" required/>
              </label>
              <label> <span>City:</span>
                <input type="text" class="input_text" name="city" id="city" required/>
              </label>
              <label> <span>State:</span>
                <input type="text" class="input_text" name="state" id="state" required/>
              </label>
              <label> <span>Pincode:</span>
                <input type="text" class="input_text" name="pincode" id="pincode" required/>
              </label><br>
              <h1>Qualification</h1>
              <label>
               <div><input type="text" name="degree_1" class="input_text" id="degree_1" required style="width:100px;" value="SSC" readonly />
               <input type="text" name="board_1" id="board_1" class="input_text" required style="width:140px;"  placeholder="Board/University"/>
               <input type="text" name="course" class="input_text" id="course" required style="width:150px;"  placeholder="Stream/Specilization" readonly/><input type="hidden" name="course_1" value="null"/>
               <input type="text" name="percentage_1" class="input_text" id="percentage_1" required style="width:100px;"  placeholder="Percentage"/>
               </div>
              </label>
              
                            <label>
               <div><input type="text" name="degree_2" class="input_text" id="degree_2" required style="width:100px;" value="HSSC" readonly />
               <input type="text" name="board_2" id="board_2" class="input_text" required style="width:140px;"  placeholder="Board/University"/>
               <input type="text" name="course_2" class="input_text" id="course_2" required style="width:150px;"  placeholder="Stream/Specilization"/>
               <input type="text" name="percentage_2" class="input_text" id="percentage_2" required style="width:100px;"  placeholder="Percentage"/>
               </div>
              </label>
              
                            <label>
               <div id="quali"><input type="text" name="degree_3" class="input_text" id="degree_3" required style="width:100px;" value="Graduation" readonly />
               <input type="text" name="board_3" id="board_3" class="input_text" required style="width:140px;"  placeholder="Board/University"/>
               <input type="text" name="course_3" class="input_text" id="course_3" required style="width:150px;"  placeholder="Stream/Specilization"/>
               <input type="text" name="percentage_3" class="input_text" id="percentage_3" required style="width:100px;"  placeholder="Percentage"/>
               <input type="button" id="add" onClick="addquali()" value="+"  class="add-button" /><br>
               </div>
              </label>
              <br>
               <h1>Other Details</h1>
               <label> <span>Upload Photo:</span>
                <input type="file" class="input_text" name="photo" id="uphoto" required/>
              </label>
              <label> <span>Upload Sign:</span>
                <input type="file" class="input_text" name="sign" id="usign" required/>
              </label>
               <label id="cst" style="display: none"> <span>Upload Caste Certificate:</span>
                <input type="file" class="input_text" name="castecert" id="castecert" required style="display: none"/>
              </label>
              
              <div>
                <input type="submit" class="button" value="Register" name="register"/>
                <a href="mail.php?id='.$row['PERSON_ID'].'" class="button" value="PayNext" name="paynxt">PayNext</a>
				<div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
