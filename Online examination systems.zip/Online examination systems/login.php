<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
<style type="text/css">
#apDiv1 {
	position: absolute;
	width: 200px;
	height: 115px;
	z-index: 1;
	left: 1043px;
	top: 87px;
}
</style>
</head>
<body>
<div class="header-wrap">
	<div class="logo">
		<img src="images/large.png" />
    </div>
	<div id="apDiv1"><a href="login.php" role="button" >Login</a> or 
                            <a href="#registerModal" role="button" data-toggle="modal">Register</a></div>
</div><!---header-wrap-End--->

<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
	  </li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
	  </li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Log in</h1>
        </div>
        <div class="content">
          <form action="log1.php" method="post">
            <div class="contact-form">
              <label> <span>Type of User:</span>
                <select class="input_text" name="usertype">
                     <option value="User">Candidate</option>
                     <option value="Supervisor">Supervisor</option>
                     <option value="Instructor">Instructor</option>
                     <option value="Organisation">Organisation</option>
                </select>    
                
              </label>
              <label> <span>Username:</span>
                <input type="text" class="input_text" name="uname" id="uname" required="required"/>
              </label>
              <label> <span>Password:</span>
                <input type="password" class="input_text" name="pass" id="pass" required="required"/>
              </label>
               <div>
                <input type="submit" class="button" value="Log in" />
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
