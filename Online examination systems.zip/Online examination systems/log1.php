<?php
include('conn.php');

$utype=$_POST['usertype'];
$user=$_POST['uname'];
$pass=$_POST['pass'];

if($user == "admin") 
{
	$sql = "select * from admin where auname='$user' and apass='$pass'";
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_array($result, OCI_BOTH);
	if($row)
	{
		session_start();
		echo $_SESSION['ADMINID']=$row['ADMINID'];
		echo "<script type='text/javascript'>window.alert('Admin logged in Successfully')
		window.location='admin.php';</script>";
	}
	else
	{
		echo "<script type='text/javascript'>window.alert('Please check ur Username or Password')
		window.location='login.php';</script>";
	}
}
else if($utype == "Supervisor")
{
	$sql = "select * from supervisor where SUPERVISOR_ID='$user' and PASSWORD='$pass'";
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_array($result, OCI_BOTH);
	if($row)
	{
		session_start();
		$_SESSION['SUPERVISOR_ID']=$row['SUPERVISOR_ID'];
		echo "<script type='text/javascript'>window.alert('Supervisor logged in Successfully')
		window.location='suphome.php';</script>";
	}
	else
	{
		echo "<script type='text/javascript'>window.alert('Please check ur Username or Password')
		window.location='login.php';</script>";
	}
}
else if($utype == "Instructor")
{
	$sql = "select * from instructor where INSTRUCTOR_ID='$user' and PASSWORD='$pass'";
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_array($result, OCI_BOTH);
	if($row)
	{
		session_start();
		$_SESSION['INSTRUCTOR_ID']=$row['INSTRUCTOR_ID'];
		echo "<script type='text/javascript'>window.alert('Instructor logged in Successfully')
		window.location='insthome.php';</script>";
	}
	else
	{
		echo "<script type='text/javascript'>window.alert('Please check ur Username or Password')
		window.location='login.php';</script>";
	}
}
else if($utype == "Organisation")
{
	$sql = "select * from organisation where ORGAN_ID='$user' and PASSWORD='$pass'";
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_array($result, OCI_BOTH);
	if($row)
	{
		session_start();
		$_SESSION['ORGAN_ID']=$row['ORGAN_ID'];
		echo "<script type='text/javascript'>window.alert('Organisation logged in Successfully')
		window.location='orgnhome.php';</script>";
	}
	else
	{
		echo "<script type='text/javascript'>window.alert('Please check ur Username or Password')
		window.location='login.php';</script>";
	}
}
else if($utype == "User")
{
	$sql = "select * from candidate where cust_uname='$user' and cust_pass='$pass'";
	$result = oci_parse($connection, $sql);
	oci_execute($result);
	$row = oci_fetch_array($result, OCI_BOTH);
	if($row)
	{
		session_start();
		$_SESSION['CUST_UNAME']=$row['CUST_UNAME'];
		$_SESSION['CUST_PASS']=$row['CUST_UNAME'];
		echo "<script type='text/javascript'>window.alert('User logged in Successfully')
		window.location='h1.php';</script>";
	}
	else
	{
		echo "<script type='text/javascript'>window.alert('Please check ur Username or Password')
		window.location='login.php';</script>";
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
	  </li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
	  </li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Log in</h1>
        </div>
        <div class="content">
          <form action="log1.php" method="post">
            <div class="contact-form">
              <label> <span>Type of User:</span>
                <select class="input_text" name="usertype">
                     <option value="User">Candidate</option>
                     <option value="Supervisor">Supervisor</option>
                     <option value="Instructor">Instructor</option>
                     <option value="Organisation">Organisation</option>
                </select>    
                
              </label>
              <label> <span>Username:</span>
                <input type="text" class="input_text" name="uname" id="uname" required="required"/>
              </label>
              <label> <span>Password:</span>
                <input type="password" class="input_text" name="pass" id="pass" required="required"/>
              </label>
               <div>
                <input type="submit" class="button" value="Log in" />
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
