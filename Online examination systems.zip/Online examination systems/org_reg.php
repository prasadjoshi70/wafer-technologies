<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
	

	if (isset($_POST['register']) && $_SERVER["REQUEST_METHOD"] == "POST")
	{
		include "conn.php";
		
		$orgname=$_POST['orgname'];
		$examname=$_POST['examname'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$child_1=$_POST['child_1'];
		$pass1=$_POST['pass1'];
		$cat='no_category';
		$quetno=0;
		$type='p';
		$edate='sysdate';
		
		$query = "INSERT INTO Organisation(ORGAN_ID ,ORGAN_NAME,address,email,phone,password) 
		VALUES(organ_sequence.nextval,'$orgname','$address','$email','$child_1','$pass1')";
		$q = oci_parse($connection, $query);
		oci_execute($q);
		
		$query2 = "INSERT INTO Exam(EXAM_NAME,EXAM_DATE,TYPE)VALUES('$examname',sysdate,'$type')";
		$q2= oci_parse($connection, $query2);
		oci_execute($q2);
		
		$query3 = "INSERT INTO Rules(EXAM_NAME,EXAM_DATE,TYPE)VALUES('$examname',sysdate,'$type')";
		$q3= oci_parse($connection, $query3);
		oci_execute($q3);
		
		$query4 = "INSERT INTO QuestionGenerator(EXAM_NAME,EXAM_DATE,TYPE,CATEGORY,QUESTION_NO)VALUES('$examname',sysdate,'$type','$cat','$quetno')";
		$q4= oci_parse($connection, $query4);
		oci_execute($q4);
		
		$query5 = "INSERT INTO Consolidated(EXAM_NAME,EXAM_DATE,TYPE)VALUES('$examname',sysdate,'$type')";
		$q5= oci_parse($connection, $query5);
		oci_execute($q5);
		
	}
	
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>ORGANISATION REGISTRATION</h1>
        </div>
        <div class="content">
          <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <div class="contact-form">
              
              <label><span> Organistion Name:</span>
                <input type="text" class="input_text" name="orgname" id="orgname" required/>
              </label>
              <label><span> Examination Name:</span>
                <input type="text" class="input_text" name="examname" id="examname" required/>
              </label>
               <label> <span>Address:</span>
                <textarea name="address" class="input_text" id="address" required></textarea>
              </label>
               <label> <span>Email:</span>
                <input type="email" class="input_text" name="email" id="email" required/>
              </label>
               <label><span>Phone No.:</span>
                <input name="child_1" type="text" id="child_1" class="input_text" required/>
              </label>
              <label> <span>Password:</span>
                <input type="password" class="input_text" name="pass1" id="pass1" required/>
              </label>
              <div>
                <input type="submit" class="button" value="Register" name="register" />
            </div> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
