<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
	<?php
	include "conn.php";
	$query1="select * from supervisor" ;
	$result1=oci_parse($connection,$query1);
	oci_execute($result1);
	$query2="select * from exam" ;
	$result2=oci_parse($connection,$query2);
	oci_execute($result2);
	
//	$id1=$_REQUEST['id'];
	if (isset($_POST['Assign_Supervisor']) && $_SERVER["REQUEST_METHOD"] == "POST")
	{
		include "conn.php";
		$sname=$_POST['sname'];
		$examname=$_POST['examname'];
		$edate=$_POST['edate'];
		$etime=$_POST['etime'];
		$venue=$_POST['venue'];
		$query="UPDATE supervisor SET VENUE='$venue',TIME_OF_EXAM ='$etime',EXAM_DATE=To_date('$edate','yyyy-mm-dd') where FULL_NAME='$sname'";
		$result=oci_parse($connection,$query);
		  oci_execute($result);
		  $RowsAffected=oci_num_rows($result);
			/*if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('payment done Successfully')
						window.location='studentreg.php';</script>";
			}*/
	
		
		
	}


?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Assign Supervisor</h1>
        </div>
        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <div class="contact-form">

              <label> <span>Supervisor Name:</span>
                <select class="input_text" name="sname">
                    <?php while(($row=oci_fetch_array($result1, OCI_BOTH))){?>
				 <option><?php echo $row['FULL_NAME'];?></option>
				 <?php }?>
                </select>  
               <label> <span>Exam Name:</span>
                 <select class="input_text" name="examname">
                    <?php while(($row=oci_fetch_array($result2, OCI_BOTH))){?>
				 <option><?php echo $row['EXAM_NAME'];?></option>
				 <?php }?>
                </select>  
              </label>
               <label> <span>Exam Date:</span>
                <input type="date" class="input_date" name="edate" id="edate" required="required"/>
              </label>
			  <label> <span>Exam Time:</span>
                <input type="text" class="input_date" name="etime" id="etime" required="required"/>
				<!--input type="time" class="input_date" value="<!--?php $date = date("H:i", strtotime($row['time_d'])); echo "$date"; ?>" id="until_t" name="etime" /-->
              </label>
               <label> <span>Exam Venue:</span>
                 <select class="input_text" name="venue">
				     <option value="">select exam venue</option>
                     <option value="Mapusa">Mapusa</option>
                     <option value="Panaji">Panaji</option>
                     <option value="vasco">vasco</option>
                     <option value="Margao">Margao</option>
                </select>  
              
              </label>
               <div>
                <input type="submit" class="button" value="Assign Supervisor" name="Assign_Supervisor"/>

            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
