<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
	

	if (isset($_POST['register']) && ($_SERVER["REQUEST_METHOD"] == "POST"))
	{

		$name=$_POST['name'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$pass1=$_POST['pass1'];
		$child_1=$_POST['child_1'];
		$Uni_details=$_POST['Uni_details'];
		$noquestion=$_POST['noquestion'];
		$degree=$_POST['degree'];
		$image=file_get_contents($_FILES['image']['tmp_name']);
		//echo $image_name=addslashes($_FILES['image']['name']);
		$image_size = getimagesize($_FILES['image']['tmp_name']);
		if($image_size==FALSE)
		{
			echo "that's  not an image";
		}   
		else
		{
			include "conn.php";
			$sql = "INSERT INTO instructor (INSTRUCTOR_ID,FULL_NAME ,ADDRESS,EMAIL,PASSWORD,PHONE ,UNIDET,DEGREE,NO_OF_QUESTIONS_PROVIDED,SIGN)values(inst_sequence.nextval,'$name','$address','$email','$pass1','$child_1','$Uni_details','$degree','$noquestion',empty_blob())RETURNING SIGN INTO :image";
			$result = oci_parse($connection, $sql);
			$blob = oci_new_descriptor($connection, OCI_D_LOB);
			oci_bind_by_name($result, ":image", $blob, -1, OCI_B_BLOB);
			oci_execute($result, OCI_DEFAULT) or die ("Unable to execute query");
			if ($result==true)
			{
				echo "<script language=\"javascript\" type=\"text/javascript\"> alert('Recorded Successfully'); </script>";
			}
			else
			{
				echo "<script language=\"javascript\" type=\"text/javascript\"> alert('Recorded unSuccessfully'); </script>";
			}
			$RowsAffected=oci_num_rows($result);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('Registration done in Successfully')
						window.location='inst_mail.php';</script>";
			
			}

			if(!$blob->save($image)) {
				oci_rollback($connection);
		}
		else {
				oci_commit($connection);
		}

			oci_free_statement($result);
			$blob->free();
		}
	}
	
	//oci_execute($q);
	
?>
		
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>INSTRUCTOR REGISTRATION</h1>
        </div>
        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
            <div class="contact-form">
              <label><h1>Personal Information:</h1></label>
    
              <label> <span>Name:</span>
                <input type="text" class="input_text" name="name" id="name" required/>
              </label>
              <label> <span>Address:</span>
                <textarea name="address" id="textarea" class="input_text" required></textarea>
              </label>
               <label> <span >Email:</span>
                <input type="email" class="input_text" name="email" id="email" required/>
              </label>
              <label> <span >Password:</span>
                <input type="password" class="input_text" name="pass1" id="pass1" required/>
              </label>
              <label><span>Phone No.:</span>             
                <input name="child_1" type="text" id="child_1" class="input_text" required />           
              </label>
              
              <br><br><br>
              <label><h1>Qualifications Details:</h1></label>
              <label><span>University Details: </span>
                <input type="text" class="input_text" name="Uni_details" id="Uni_details" required/>
              </label>
               <label><span>Degree:</span>  
                <input type="text" class="input_text" name="degree" id="degree" required/>
              </label>
              <label> <span>No.of questions provided:</span>
                <input type="text" class="input_text" name="noquestion" id="question" required/>
              </label>
              <label> <span>Signiture: </span>
                <input type="file" name="image" id="fileField" required class="input_text" />
              </label>
              
               <div>
                <input type="submit" class="button" value="Register" name="register" />
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
