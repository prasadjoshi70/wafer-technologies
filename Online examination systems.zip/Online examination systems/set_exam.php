<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="wrapper">
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Exam:Set</h1>
        </div>
        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <div class="contact-form">
              <label><h1>&nbsp;</h1>
              </label>
              <br>
              
              <label>
              <select name="select" id="examname">
                <option>Exam Name</option>
                <option>set</option>
                <option>gate</option>
                <option>cat</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
<select name="select1" id="type">
                <option>Type</option>
                <option>P</option>
                <option>M</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
<select name="select3" id="level">
  <option>Level</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
<select name="select1" id="marks">
  <option>Marks</option>
  <option>1</option>
  <option>2</option>
  <option>3</option>
</select>
&ensp;&ensp;&ensp;&ensp;
<select name="select1" id="category">
  <option>Category</option>
  <option>Appt</option>
  <option>Comp</option>
  <option>GK</option>
</select>
            </label>
              <br>
              <label>Here All question will appear
              
              
              
              
              </label>
              <label>
             
              
              Apttitude total question:
                <input name="textfield" type="text" id="apttitude" readonly="readonly" /><br /><br />
                 GK total question:&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                 <input name="textfield" type="text" id="gk" readonly="readonly" /><br /><br />
                 Computer total question:
                 <input name="textfield" type="text" id="computer" readonly="readonly" /><br /><br />
              </label>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
