<!DOCTYPE html>
<html>
<title>Exam Interface</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/w33s.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
#apDiv1 {
	position: absolute;
	width: 200px;
	height: 335px;
	z-index: 1;
	left: 909px;
	top: 158px;
}
#apDiv2 {
	position: absolute;
	width: 907px;
	height: 53px;
	z-index: 2;
}
</style>
<body class="w3-theme-l5">

<!-- Navbar -->
<div class="w3-top">
 <ul class="w3-navbar w3-theme-d2 w3-left-align w3-large">
  <li class="w3-hide-medium w3-hide-large w3-opennav w3-right">
    <a class="w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  </li>
  <li><img src="images/square.png" width="177" height="134" class="w3-padding-large w3-theme-d4" /></li>
  

  <li class="w3-hide-small w3-right"><a href="#" class="w3-padding-large w3-hover-white" title="My Account"><img src="/w3images/avatar2.png" class="w3-circle" style="height:25px;width:25px" alt="Avatar"></a></li>
 </ul>
</div>
<div id="apDiv2"><div class="menu28">
    <ul>
      <li><a href="#" class="active">Home</a></li>
      <li><a href="#">Quest-Paper</a></li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div></div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:51px">
  <ul class="w3-navbar w3-left-align w3-large w3-theme">
    <li><a class="w3-padding-large" href="#">Link 1</a></li>
    <li><a class="w3-padding-large" href="#">Link 2</a></li>
    <li><a class="w3-padding-large" href="#">Link 3</a></li>
    <li><a class="w3-padding-large" href="#">My Profile</a></li>
  </ul>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">
  <!-- The Grid -->
<div class="w3-row">
    <!-- Left Column --><!-- Middle Column -->
    
    
  <div class="col-md-10 column">
	<p class="lead">Question</p>
	<div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">
						what is ur name?
	    </h3>
      </div>
      <div class="panel-body">
        <div class="radio">
          <label>
            <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked=""> Option1
          </label>
        </div>
        <div class="radio">
          <label>
            <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2"> Option2
          </label>
        </div>
        <div class="radio">
          <label>
            <input type="radio" name="optionsRadios" id="optionsRadios3" value="option3"> Option3
          </label>
        </div>
        <div class="radio">
          <label>
            <input type="radio" name="optionsRadios" id="optionsRadios4" value="option4"> Option4
          </label>
        </div>

      </div>
      <div class="panel-footer">
        <a href="#" class="btn btn-primary " role="button">Next</a>
       
      </div>
    </div>
  </div>
  <div id="apDiv1"><div class="panel panel-primary2">
      <div class="panel-heading">
        <h3 class="panel-title">
						Question numbers
					</h3>
      </div>
      <div class="panel-body">
        

      </div></div>
    <!-- Right Column --><!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
  <!--h5>Footer</h5-->
</footer>

<footer class="w3-container w3-theme-d5" align="center">
  <p>Powered by w3.css</a></p>
</footer>
 


</body>
</html>

