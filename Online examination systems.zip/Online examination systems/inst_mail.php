<?php
          echo "Hello";

          include "conn.php";
          $pid=0;
          $sql=oci_parse($connection,'select inst_sequence.nextval from dual');
		  oci_execute($sql);
		  
		  while(($row=oci_fetch_row($sql)) != false){
			 $pid=$row[0] - 1;
			 //echo $pid;

		  }
		  //echo $pid;
		  $to=0;
		  $sql1=oci_parse($connection,'select INSTRUCTOR_ID,email from instructor where INSTRUCTOR_ID='.$pid.'');
		  oci_execute($sql1);
		  
		  while(($row=oci_fetch_array($sql1, OCI_BOTH)) != false){
			  
			  $to=$row['EMAIL'];
			  
		  }
		  
          $subject = "Registration id Details:";
		  $message = "instructor ID: ".$pid."\n";
		  $headers = "instructor Details:";
		  
		  mail($to,$subject,$message,$headers);
		  
		  echo "<script type='text/javascript'>window.alert('Email has been sent to your registered Email-ID')
						window.location='Inst_reg.php';</script>";
		  
?>