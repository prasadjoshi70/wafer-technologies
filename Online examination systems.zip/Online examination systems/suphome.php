<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header-wrap">
	<div class="logo">
    </div>
</div><!---header-wrap-End--->

<div class="menu-wrapper">
  
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li><a href="Sup_view_profile.php">Manage Profile</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="banner-wrapper">
    <div class="banner">  </div>
    
    <div class="clearing"></div>
  </div>
  <div class="page-wrapper">
    <table width="84%" height="102" border="0">
      <tr>
        <td><p><strong>Online Examination</strong></p>
        <p>&nbsp;</p></td>
      </tr>
      <tr>
        <td><p>VLAP Online Examination System is the simplest-to-use web-based application </p>
          <p>for  schools, colleges, university, coaching classes, training centres, certification agencies, recruitment </p>
          <p>firms to conduct timer-based, completely automated, paperless examinations. </p>
          <p> </p>
          <p>VLAP is a pioneer in providing                 'Online Examination Software' to leading educational institutes, </p>
          <p>which emerged as very useful tool for                 students to prepare for no. of competitive exams. <br />
            <br />
            Today, almost all exams and recruitment tests  are being conducted                 in online mode. </p>
          <p>If a candidate is going to appear for exam in online format then he must get prepared in a <br />
            similar environment. VLAP online exam software is the best solution to prepare for timer-based,<br />
        objective-type (MCQ) exams.</p>
        <p>&nbsp;</p></td>
      </tr>
    </table>
    <div class="primary-content">
      <div class="panel">
        <div class="title">
          <h1>Why it is must-to-have?</h1>
          <p>&nbsp;</p>
        </div>
        <div class="content">
          <ul>
            <li><strong>Simplest</strong>-to-use &amp; most user friendly interface </li>
            <li></li>
            <li><strong>Lowest</strong> <strong>guranteed price</strong> yet maximum quality features offered</li>
            <li></li>
            <li><strong>Easy-</strong>to-adopt &amp; affordable customization </li>
            <li><strong>Built-to-suit</strong> needs of any exam pattern</li>
            <li><strong>Secure</strong>,reliable &amp; scalable</li>
            <li><strong>Choice to host</strong> anywhere - your website, cloud, institute server</li>
            <li><strong>Truely Unlimited</strong>! - no restriction on no. of users / tests. You completely own whole system</li>
            <li><strong>Complete freedom</strong> to define your own exam pattern</li>
          </ul>
          <p>&nbsp;</p>
          <div class="button-link"></div>
        </div>
      </div>
    </div>
    <div class="sidebar">
      <div class="panel">
        <div class="title">
          <h1>Salient Features</h1>
          <p>&nbsp;</p>
        </div>
        <div class="content">
          <ul>
            <li><strong>Question Bank</strong> - Built-in question management, categorised as subjects,topics, sub-topics, difficulty level </li>
            <li><strong>Candidate/Student Management</strong> - Very easy to add, manage student database with dedicated dashboard </li>
            <li><strong>Exam/Test Management</strong>- Create, assign &amp; publish exams for selected group of students </li>
            <li><strong>Results &amp; Analysis-</strong> Get instant results on exam completion with certificate, explanations for questions &amp; graphical analysis </li>
            <li><strong>Messaging-</strong> Built-in information management to get latest news, updates, shared articles</li>
          </ul>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>