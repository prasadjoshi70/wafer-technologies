<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
<!-- script for phone number-->


<!-- script for Qualification-->
<script type="text/javascript">
var i = 1;
var limit = 2;
counter=0;
function addquali(){
	if (i == limit){
		alert("You have reached the limit of adding " + i-1);
     }
	else {	
		
    	var newdiv = document.createElement('div');
		//div.style.width = "100px";
		newdiv.style.height = "50px";
		newdiv.style.color = "white";
		
		//div.setAttribute('class', 'myclass');
    	newdiv.innerHTML ='<input type="text" name="degree_4" class="input_text" id="degree_4" required style="width:100px;" value="PG" readonly /><input type="text" name="board_4" id="board_4" class="input_text" required style="width:140px;"  placeholder="Board/University"/><input type="text" name="course_4" class="input_text" id="course_4" required style="width:150px;"  placeholder="Stream/Specilization"/><input type="text" name="percentage_4" class="input_text" id="percentage_4" required style="width:100px;"  placeholder="Percentage"/><input type="button" id="add" onClick="addquali()" value="+" class="add-button" /><input type="button" value="-" onclick="removequali(this)" class="add-button" />';

    	document.getElementById('quali').appendChild(newdiv);
		i++;
		
	}
	counter=i;
	document.getElementById('count').value=counter;
	
}

function removequali(div) {	
    document.getElementById('quali').removeChild( div.parentNode );
	i--;
}
</script>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Manage Instructor</h1>
        </div>
        <div class="content">
		
          <div class="contact-form1">
           <table width="619" border="1">
             <tr>
             <td width="13">ID</td>
             <td width="51">Full Name</td>
               <!--<td width="57">Address</td-->
                 <td width="148">Email</td>
                 <td width="115">Phone </td>
                  <!--td width="145">University Details</td-->
                 <td width="88">Degree</td>
                  <td width="164">Number Of Questions</td>
                 <td width="164">Edit</td>
                 <td width="164">Delete</td>
               </tr>	
		  <?php		
			include "conn.php";
				$sql1 = "select * from instructor";
				$result1 = oci_parse($connection, $sql1);
				oci_execute($result1);
				 while(($row=oci_fetch_array($result1, OCI_BOTH)) != false)
				{
					 $id=$row['INSTRUCTOR_ID'];
					 $name=$row['FULL_NAME'];
					 $add=$row['ADDRESS'];
					 $email=$row['EMAIL'];
					 $phone=$row['PHONE'];
					 $unidet=$row['UNIDET'];
					 $degree=$row['DEGREE'];
					 $noqest=$row['NO_OF_QUESTIONS_PROVIDED'];	
					

                echo '<tr>';
                 echo '<td width="13">'.$id.' </td>';
                 echo '<td width="51"> '.$name.' </td>';
                //  echo' <td width="57"> '.$add.' </td>';
                  echo '<td width="148">  '.$email.'</td>';
                 echo '<td width="115">  '.$phone.' </td>';
                 // echo '<td width="145"> '.$unidet.' </td>';
                 echo '<td width="88"> '.$degree.'</td>';
                  echo ' <td width="164"> '.$noqest.'</td>';
				
                  echo '<td width="57"> <a href="Inst_view.php?id='.$row['INSTRUCTOR_ID'].'" class="add-button" value="Edit" />Edit</a></td>';
                 echo '<td width="57"> <a href="delete_inst.php?id='.$row['INSTRUCTOR_ID'].'" class="add-button" value="Delete" />Delete</a></td>';
				 
                echo '</tr>';
				}
				?>
             </table>
           </div>
			
			
          
		
		  
        </div>
      </div>
    </div>
  </div>
</div>

<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
