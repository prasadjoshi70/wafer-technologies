<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
session_start();
include "conn.php";
		  
			//$id1=$_REQUEST['id'];  
			$id1=$_SESSION['INSTRUCTOR_ID'];
		  
		  $inst="select * from instructor where INSTRUCTOR_ID='$id1'";
		  $result=oci_parse($connection,$inst);
		  oci_execute($result);
		  
		  while(($row=oci_fetch_array($result, OCI_BOTH)) != false){
			$id=$row['INSTRUCTOR_ID'];
			 $name=$row['FULL_NAME'];
			 $add=$row['ADDRESS'];
			 $email=$row['EMAIL'];
			 $phone=$row['PHONE'];
			 $unidet=$row['UNIDET'];
			 $degree=$row['DEGREE'];
			 $noqest=$row['NO_OF_QUESTIONS_PROVIDED'];	
		  
		  }
		
		  ?>

		
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>EDIT INSTRUCTOR</h1>
        </div>
        <div class="content">
		 <form action="Inst_update.php" method="post">
		<?php
		
			  echo'<div class="contact-form">';
              echo'<label><h1>Personal Information:</h1></label';
    
              echo'<label> <span>Name:</span>';
			  echo '<input type="hidden" name="id" value="'.$id.'" readonly />';
                echo'<input type="text" class="input_text" name="name" id="name" value="'.$name.'" readonly/>';
              echo'</label>';
              echo'<label> <span>Address:</span>';
                echo'<textarea name="address" id="textarea" class="input_text" required>'.$add.'</textarea>';
              echo'</label>';
               echo'<label> <span >Email:</span>';
                echo'<input type="email" class="input_text" name="email" id="email" value="'.$email.'" readonly/>';
              echo'</label>';
              echo'<label><span>Phone No.:</span>';             
                echo'<input name="child_1" type="text" id="child_1" class="input_text" value="'.$phone.'" required /> ';          
              echo'</label>';
              
              echo'<br><br><br>';
              echo'<label><h1>Qualifications Details:</h1></label';
              echo'<label><span>University Details: </span>';
                echo'<input type="text" class="input_text" name="Uni_details" id="Uni_details" value="'.$unidet.'" required/>';
              echo'</label>';
               echo'<label><span>Degree:</span>'; 
                echo'<input type="text" class="input_text" name="degree" id="degree" value="'.$degree.'" required/>';
              echo'</label>';
              echo'<label> <span>No.of questions provided:</span>';
                echo'<input type="text" class="input_text" name="noquestion" id="question" value="'.$noqest.'" required/>';
              echo'</label>';
               echo'<div>';
                echo'<input type="submit" class="button" value="Update" name="update" />';
            echo'</div>';
            echo'</div>';
         ?>
		 </form>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
