<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->

<?php
	//$id1=$_REQUEST['id'];
	if (isset($_POST['payment']) && $_SERVER["REQUEST_METHOD"] == "POST")
	{
		include "conn.php";
		$id1=$_POST['pid'];		
		$payment='1';
		$mode=$_POST['mode'];
		$bank=$_POST['bank'];
		$amount=$_POST['amount'];
		$query = "UPDATE person SET PAYMENT='$payment',PAYMENT_MODE ='$mode',BANK_NAME='$bank',PAYMENT_AMOUNT='$amount' where person_id='$id1'";
		//$query="UPDATE supervisor SET FULL_NAME='$sname',ADDRESS='$sadd',EMAIL='$semail' ,SUPERVISOR_PHONE='$sphone',QUALIFICATION='$sunidet',DEGREE='$sdegree' where SUPERVISOR_ID='.$id1.'";
		$result=oci_parse($connection,$query);
		  oci_execute($result);
		  $RowsAffected=oci_num_rows($result);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('payment done Successfully')
						window.location='studentreg.php';</script>";
			}
		//update exam table;
	}


?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>PAYMENT</h1>
        </div>
        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <?php
            $id1=$_POST['pid'];
			
			echo '<div class="contact-form">';
              
              echo '<input type="hidden" name="pid" id="pid" value="'.$id1.'" />';
              echo '<label> <span>Type of mode:</span>
                <select class="input_text" name="mode">
					 <option value=""></option>
                     <option value="debit card">Debit card</option>
                     <option value="credit card">Credit card</option>
                </select>'; 
             echo '</label>';
              
              echo '<label> <span>Name of Bank:</span>
					<input type="text" class="input_text" name="bank" id="bank" required/>
              </label>';
               echo '<label> <span >Amount:</span>
                <input type="text" class="input_text" name="amount" id="amount" required/>
              </label>';
              
               echo '<div>
                <input type="submit" class="button" value="Pay" name="payment" />
                <input type="submit" class="button" value="Skip" />
            </div>';
            echo '</div>';
			?>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
