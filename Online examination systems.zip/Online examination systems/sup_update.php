<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
include "conn.php";
?>
	 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>EDIT supervisor</h1>
        </div>
        <div class="content">
		 
        </div>
      </div>
    </div>
  </div>
</div>

<?php
//aid=$row['INSTRUCTOR_ID
			if((isset($_POST['update']) &&( $_SERVER["REQUEST_METHOD"] == "POST"))){
			 $id1=$_POST['id'];
			 $sname=$_POST['name'];
			 $sadd=$_POST['address'];
			 $semail=$_POST['email'];
			 $sphone=$_POST['child_1'];
			 $sunidet=$_POST['Uni_details'];
			 $sdegree=$_POST['degree'];
			//$query="UPDATE instructor SET FULL_NAME='$_POST['name']',ADDRESS='$_POST['address']',EMAIL='$_POST['email'] ',PHONE='$_POST['child_1']',UNIDET='$_POST['Uni_details']',DEGREE='$_POST['degree']',NO_OF_QUESTIONS_PROVIDED='$_POST['noquestion']' where INSTRUCTOR_ID='.$id1.'";

		$query="UPDATE supervisor SET FULL_NAME='$sname',ADDRESS='$sadd',EMAIL='$semail' ,SUPERVISOR_PHONE='$sphone',QUALIFICATION='$sunidet',DEGREE='$sdegree' where SUPERVISOR_ID='$id1'";
			$result=oci_parse($connection,$query);
		  oci_execute($result);
		  $RowsAffected=oci_num_rows($result);
			if($RowsAffected)
			{
			
				echo "<script type='text/javascript'>window.alert('Update done Successfully')
						window.location='manage_supervisor.php';</script>";
			
			}
			}
?>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
