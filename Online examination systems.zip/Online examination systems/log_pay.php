<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<?php
	

	if (isset($_POST['pay']) && $_SERVER["REQUEST_METHOD"] == "POST")
	{
		include "conn.php";
		
		$pid=$_POST['pid'];
		$dob=$_POST['dob'];
	}
	
?>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>PAYMENT LOGIN</h1>
        </div>
        <div class="content">
          <form method="post" action="payment.php">
            <div class="contact-form">

              <label> <span>Person Id:</span>
<input type="text" class="input_text" name="pid" id="pid" required="required"/>
              </label>
               <label> <span>Date Of Birth:</span>
                <input type="date" class="input_text" name="dob" id="birth" min="1966-01-01" max="1995-12-31" required/>
              </label>
              
               <div>
			    <!--a href="payment.phpid='.$row['SUPERVISOR_ID'].'"" class="button" value="Pay" name="pay">PayNext</a>
                <!--input type="submit" payment class="button" value="Login" /-->
			    <input type="submit" class="button" value="Pay" name="pay" />

            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
