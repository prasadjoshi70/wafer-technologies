<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
 <?php		
					include ('conn.php');
					
					$id1=$_SESSION['ORGAN_ID'];
					$sql1 = "select * from organisation where ORGAN_ID='$id1'";
					$result1 = oci_parse($connection, $sql1);
					oci_execute($result1);
					 while(($row=oci_fetch_array($result1, OCI_BOTH)) != false)
					{
						 $orgid=$row['ORGAN_ID'];
						 $orgname=$row['ORGAN_NAME'];
						 $add=$row['ADDRESS'];
						 $email=$row['EMAIL'];
						 $phone=$row['PHONE'];
						 //$Examname=$row[''];
					}
         ?>
<script type="text/javascript">
var i = 1;
var limit = 3;
function addKid(){
	if (i == limit){
		alert("You have reached the limit of adding " + i);
     }
	else {	
		
    	var newdiv = document.createElement('div');
		//div.style.width = "100px";
		newdiv.style.height = "50px";
		newdiv.style.color = "white";
		
		//div.setAttribute('class', 'myclass');
    	newdiv.innerHTML ='&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;<input type="text" name="child_'+i+'" class="input_text" required="required" /><input type="button" id="add" onClick="addKid()" value="+" class="add-button" /><input type="button" value="-" onclick="removeKid(this)" class="add-button" />';
    	document.getElementById('kids').appendChild(newdiv);
		i++;
	}
}

function removeKid(div) {	
    document.getElementById('kids').removeChild( div.parentNode );
	i--;
}
</script>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>ORGANISATION REGISTRATION</h1>
        </div>
        <div class="content">
		<form action="org_update.php" method="post">
            <?php
            echo '<div class="contact-form">';
			echo ' <label><span> Organistion Id:</span>';
               echo '  <input type="text" class="input_text" name="orgid" id="orgid" value="'.$orgid.'" required/>';
              echo ' </label>';
              echo ' <label><span> Organistion Name:</span>';
               echo '  <input type="text" class="input_text" name="orgname" id="orgname" value="'.$orgname.'" required/>';
              echo ' </label>';
               echo ' <label> <span>Address:</span>';
			  echo'<textarea name="address" id="textarea" class="input_text" required>'.$add.'</textarea>';
              //echo '   <textarea name="address" class="input_text" id="textarea" value="'.$add.'" placeholder="'.$add.'" required></textarea>';
              echo ' </label>';
              echo '  <label> <span>Email:</span>';
               echo '  <input type="email" class="input_text" name="email" id="email" value="'.$email.'" required/>';
              echo ' </label>';
              echo '  <label><span>Phone No.:</span>';
              echo ' <div id="kids">';
               echo '  <input name="child_1" type="text" id="child_1" class="input_text" value="'.$phone.'" required/>';
              echo ' </div>';
              echo ' </label>';
            /*  echo ' <label> <span>Password:</span>';
              echo '   <input type="text" class="input_text" name="pass" id="pass" value="'.$pw.'" required/>';
              echo ' </label>';*/
               echo '<div>';
                echo ' <input type="submit" class="button" value="Update" name="update" />';
             echo '</div> ';
             echo '</div>';
			?>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh is a idot</a></p>
    <p>Images  From : He needs to brush up his div tag html #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
