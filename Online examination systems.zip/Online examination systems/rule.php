<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<?php
	if (isset($_POST['submit']))
	{
		include "conn.php";
		//$ename=$_POST['ename'];
		$ename=$_POST['ename'];
		$edate=$_POST['edate'];
		$time=$_POST['time'];
		$noquestion=$_POST['noquestion'];
		$cutoff=$_POST['cutoff'];
		$nooption=$_POST['nooption'];
		$category=$_POST['category'];
		$marks=$_POST['marks'];
		$eachquestion1=$_POST['eachquestion1'];	
		$negativemarks1=$_POST['negativemarks1'];
		$eachquestion2=$_POST['eachquestion2'];
		$negativemarks2=$_POST['negativemarks2'];
		$eachquestion3=$_POST['eachquestion3'];
		$negativemarks3=$_POST['negativemarks3'];	
		$type=$_POST['type'];
		/*$sql="INSERT INTO EXAM (EXAM_NAME,EXAM_DATE,DURATION,TYPE,MARKS,NO_OF_QUESTIONS)VALUES('$ename','$edate','$time','$type','$marks','$noquestion')";
		$q = oci_parse($connection, $sql);
		oci_execute($q);*/
		$sql2="INSERT INTO EXAM (EXAM_NAME,EXAM_DATE,DURATION,TYPE,MARKS,NO_OF_QUESTIONS)VALUES('$ename',To_date('$edate','yyyy-mm-dd'),'$time','$type','$marks','$noquestion')";
		$q = oci_parse($connection, $sql2);
		oci_execute($q);
		$sql3="INSERT INTO rules (TYPE,EXAM_NAME,EXAM_DATE,NO_OF_QUESTIONS,CUT_OFF,NO_OF_OPTIONS,CATEGORY,TOTAL_MARKS_QUESTIONS1,NEGATIVE_MARKS_QUESTIONS1,TOTAL_MARKS_QUESTIONS2,NEGATIVE_MARKS_QUESTIONS2,TOTAL_MARKS_QUESTIONS3,NEGATIVE_MARKS_QUESTIONS3)
		VALUES('$type','$ename',To_date('$edate','yyyy-mm-dd'),'$noquestion','$cutoff','$nooption','$category','$eachquestion1','$negativemarks1','$eachquestion2','$negativemarks2','$eachquestion3','$negativemarks3')";
		$q1 = oci_parse($connection, $sql3);
		oci_execute($q1);

	}
	
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TMPH00053</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Tienne' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="menu-wrapper">
  <div class="menu">
    <ul>
      <li><a href="#" class="current">Home</a></li>
      <li class="dropdown">
          <a href="#">Syllabus</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Quest-Paper</a></li>
      <li class="dropdown">
          <a href="#">Exam</a>
          <div class="dropdown-content">
             <a href="#">Link 1</a>
             <a href="#">Link 2</a>
    		 <a href="#">Link 3</a>
  		  </div>
		</li>
      <li><a href="#">Result</a></li>
      <li><a href="#">Impt-Date</a></li>
      <li><a href="#">Contact Us</a></li>
    </ul>
  </div>
  <div class="clearing"></div>
</div>
<div class="wrapper">
  <div class="clearing"></div>
  <div class="panel-wrapper">
    <div class="right-colum">
      <div class="panel">
        <div class="title">
          <h1>Rules</h1>
        </div>
        
        <MARQUEE WIDTH=650 HEIGHT=50  behavior=alternate><img src="images/warning.gif" height="42" width="42"><b>
Category Provided: Aptitude, General Knowlege, Computer Awarness, Logical Reasoning, Mathematics, Physics, Chemistry, Civil Engineering, Life Science, Engineering Science...</b>
</MARQUEE>
        <div class="content">
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <div class="contact-form">
            
              <label> <span>Exam Name:</span>
                <input type="text" class="input_text" name="ename" id="ename" required="required" value=""/>
              </label>
			   <label> <span>Exam date:</span>
                <input type="date" class="input_text" name="edate" id="edate"  min="2016-12-31" required/>
              </label>
			  <label> <span>Exam duration:</span>
               <input type="text" class="input_text" name="time" id="time" required="required" value=""/>
              </label>
            
             <label> <span>No Of Question:</span>
                <input type="text" class="input_text" name="noquestion" id="noofquest" required="required" value=""/>
              </label>
              <label> <span>Cut Off:</span>
                <input type="text" class="input_text" name="cutoff" id="cutoff" required="required" value=""/>
              </label>
              <label> <span>No Of Options:</span>
                <input type="text" class="input_text" name="nooption" id="noofoptn" required="required" value=""/>
              </label>
              
               <label> <span>Category:</span>
                <input type="text" class="input_text" name="category" id="category" required="required"/>
              </label>
			   <label> <span>marks:</span>
                <input type="text" class="input_text" name="marks" id="marks" required="required"/>
              </label>
              
              <br>
              
              <label>
              Marks for each Question:
              <select name="eachquestion1" id="select">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;

Negative Marks:
              <select name="negativemarks1" id="select">
				<option value="0">0</option>
                <option value="0.25">0.25</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
              </label>
              
              <label>
              Marks for each Question:
              <select name="eachquestion2" id="select">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;

Negative Marks:
              <select name="negativemarks2" id="select">
				<option value="1">0</option>
                <option value="0.25">0.25</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
              </label>
              
              <label>
              Marks for each Question:
              <select name="eachquestion3" id="select">
				<option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;

Negative Marks:
              <select name="negativemarks3" id="select">
				<option value="0">0</option>
                <option value="0.25">0.25</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
&ensp;&ensp;&ensp;&ensp;
              </label>
			  <label> EXAM TYPE: </label>
            <label>
              <input name="type" type="radio" value="p" id="radio1" />PRELIMINARY
              </label>
			  <label>
              <input name="type" type="radio" value="m" id="radio2" />MAIN
			  </label>
            </label>
              
              <br>
        	<div>
            <input type="submit" name="submit" class="button" value="ADD" />
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="footer-wrapper">
  <div class="footer">
    
  </div>
</div>
<div class="bottom">
  <div class="content">
    <p>Designed By : Alpesh</a></p>
    <p>Images  From : #w3schools#prasadjoshi#vinaykumar</a></p>
  </div>
</div>
</body>
</html>
