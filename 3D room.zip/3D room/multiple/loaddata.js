		var obj1=["cube02.obj","dustbin.obj","tv.obj"];
		var content=[];
		
	function asyncc()
	{
		for(var i=0;i<obj1.length;i++){
        $.ajax({url:obj1[i],async:false, success: function(result){
            content[i]=result;
        }});
    }
	}	

		
	

function getOBJECT_Structure(){
	
	var OBJECT_Structure = {
		
		array_vertices: null,
		array_colors: null,
		array_normals: null,
		array_indices: null,
		array_texture_cord: null,
		texture_cord_size: 0,
		
		vertex_buffer: null,
		texture_cord_buffer: null,
		color_buffer: null,
		normal_buffer:null,
		index_buffer: null,
		lightWorldPositionLocation:null,
		texture: null,
		texture_unit: null,
		image: null,
		
		mod_matrix: 
		[1,0,0,0, 
		0,1,0,0, 
		0,0,1,0, 
		-3.5,-3,0,1], //identity matrix.

		vertShaderCode: null,
		fragShaderCode: null,

		vertShader: null,
		fragShader: null,
		shaderProgram: null,

		uLoc_Pmatrix: null,
		uLoc_Vmatrix: null,
		uLoc_Mmatrix: null,
		uLoc_uTexture: null,

		aLoc_Position: null,
		aLoc_TexCoord: null,
		aLoc_Color: null,
		normalLoc:null,

		hasTexture: false,
	};
	
	return OBJECT_Structure;

}

function getObject(a){
		var obj=getOBJECT_Structure();	
		
		var oldvertices=[];
		var oldtextures=[];
		var oldnormals=[];
		var vertices=[];
		var texture_cord=[];
		var normals=[];
		var indices=[];
		var colors=[];
		
		var part="v ";
	    var part1="vt";
        var start=content[a].indexOf(part);
		var part2=content[a].slice(start + part.length);
		var part3=part2.indexOf(part1);
		var part4=part2.slice(0,part3);
		var t=part4.split(/v */g);
		var part5=t.join(" ");
		var t1=part5.split(/\n/g);
		var part51=t1.join("");
		var ver=part51.split(" ");
		for(var ii=0; ii<ver.length; ii++)
		{
		oldvertices[ii]=parseFloat(ver[ii]);
		}
		//console.log(oldvertices);
	
		//texture
		var part05="vt ";
	    var part51="vn";
        var start5=content[a].indexOf(part05);
		var part52=content[a].slice(start5 + part05.length);
		var part53=part52.indexOf(part51);
		var part54=part52.slice(0,part53);
		var t5=part54.split(/vt */g);
		var part55=t5.join(" ");
		var t51=part55.split(/\n/g);
		var part91=t51.join("");
		var tex=part91.split(" ");

		for(var ee=0; ee<tex.length; ee++)
		{
		oldtextures[ee]=tex[ee];
		}
		//console.log(oldtextures);
		
		//normals
		var part06="vn ";
	    var part61="usemtl";
        var start6=content[a].indexOf(part06);
		var part62=content[a].slice(start6 + part06.length);
		var part63=part62.indexOf(part61);
		var part64=part62.slice(0,part63);
		var t6=part64.split(/vn */g);
		var part65=t6.join(" ");
		var t61=part65.split(/\n/g);
		var part92=t61.join("");
		var nor=part92.split(" ");

		for(var ff=0; ff<nor.length; ff++)
		{
		oldnormals[ff]=nor[ff];
		}
		//console.log(oldnormals);
		
		
		//faces
		var m1="f ";
		var t2=part2.indexOf(m1);
		var ind1=part2.slice(t2 + m1.length);
		var t65=ind1.split(/f */g);
		var part65=t65.join(" ");
		var t15=part65.split(/\n/g);
		var part515=t15.join("");
		var ind=part515.split(" ");		
		var part95=ind.join(" ");
		var part96;
		var vertices_faces=[];
		var textures_faces=[];
		var normal_faces=[];
		for(var jj=0; jj<ind.length;jj++)
		{
		part96=ind[jj].split("/");
		vertices_faces[jj]=parseInt(part96[0]-1);
		textures_faces[jj]=parseInt(part96[1]-1);
		normal_faces[jj]=parseInt(part96[2]-1);
		}
		//console.log(vertices_faces);
		//console.log(textures_faces);
		//console.log(normal_faces);

		
		
		var j=0;
		console.log(vertices_faces);
		for (var yy=0; yy < ind.length; yy++)
		{
		vertices[j++]=parseFloat(oldvertices[vertices_faces[yy]* 3]);
		vertices[j++]=parseFloat(oldvertices[(vertices_faces[yy]* 3)+1]);
		vertices[j++]=parseFloat(oldvertices[(vertices_faces[yy]* 3)+2]);
		
		}
		//console.log(vertices);
		console.log(ind.length);
		for(var k=0;k<ind.length;k++)
		{
		indices[k]=k;
		}
		//console.log(indices);
		
		var j=0;
		for (var yy=0; yy < ind.length; yy++)
		{
		normals[j++]=parseFloat(oldnormals[normal_faces[yy]* 3]);
		normals[j++]=parseFloat(oldnormals[(normal_faces[yy]* 3)+1]);
		normals[j++]=parseFloat(oldnormals[(normal_faces[yy]* 3)+2]);
		}
		//console.log(normals);
		var j=0;
		for (var yy=0; yy < ind.length; yy++)
		{
		texture_cord[j++]=parseFloat(oldtextures[textures_faces[yy]* 2]);
		texture_cord[j++]=parseFloat(oldtextures[(textures_faces[yy]* 2)+1]);
		}
		
		for (var yy=0; yy < normals.length; yy++)
		{
		if(yy%3==0)
		{
		colors[yy]=1;
		}
		else
		{
		colors[yy]=0;
		}
		}
			
		for(var i=1; i<texture_cord.length; i=i+2){
			texture_cord[i]=1-texture_cord[i];
		}	
	
	obj.array_vertices=vertices;
	obj.array_colors=colors;
	obj.array_indices=indices;
	obj.array_normals=normals;
	obj.array_texture_cord=texture_cord;
	obj.texture_cord_size = obj.array_texture_cord.length;
	
/*
	obj.array_vertices = 
	[
	-2.0, 2.0, 0.0,  //v0
	-2.0, -2.0, 0.0, //v1
	2.0, -2.0, 0.0,  //v2
	2.0, 2.0, 0.0,   //v3
	];
	
	obj.array_colors =
	[
	1,0,0, //v0
	1,0,0, //v1
	1,0,0, //v2
	1,0,0, //v3
	];
	
	obj.array_texture_cord =
	[
	0.0, 1.0,
	0.0, 0.0,
	1.0, 0.0,
	1.0, 1.0,
	];
	
	obj.hasTexture = true,
	
	obj.array_indices =
	[
	0,1,2,  //t1
	2,3,0,  //t2
	];*/
	//obj.hasTexture = true;
	return obj;
}		
	

/*
function getObject2(){
	
	var obj = getOBJECT_Structure();

	obj.array_vertices = 
	[
	-1.0, 1.0, 0.0,  //v0
	-1.0, -1.0, 0.0, //v1
	1.0, -1.0, 0.0,  //v2
	1.0, 1.0, 0.0,   //v3
	];
	
	obj.array_colors =
	[
	1,0,1, //v0
	1,0,1, //v1
	1,0,1, //v2
	1,0,1, //v3
	];
	
	obj.array_indices =
	[
	0,1,2,  //t1
	2,3,0,  //t2
	];

	return obj;
}

function getObject3(){
	
		var obj = getOBJECT_Structure();

	obj.array_vertices = 
	[
	-1.0, 1.0, 0.0,  //v0
	-1.0, -1.0, 0.0, //v1
	1.0, -1.0, 0.0,  //v2
	1.0, 1.0, 0.0,   //v3
	];
	
	obj.array_colors =
	[
	1,0,0, //v0
	1,0,0, //v1
	1,0,0, //v2
	1,0,0, //v3
	];
	
	obj.array_texture_cord =
	[
	0.0, 1.0,
	0.0, 0.0,
	1.0, 0.0,
	1.0, 1.0,
	];
	obj.texture_cord_size = 8;
	obj.hasTexture = true,
	
	obj.array_indices =
	[
	0,1,2,  //t1
	2,3,0,  //t2
	];

	return obj;
}
*/