textureVertexShaderCode = 'attribute vec3 position;'+
	'attribute vec2 a_texcoord;'+
	'uniform mat4 Pmatrix;'+
	'uniform mat4 Vmatrix;'+
	'uniform mat4 Mmatrix;'+
	'attribute vec3 color;'+//the color of the point
	'varying vec3 vColor;'+
	'varying vec2 v_texcoord;'+
	'void main(void) { '+
	   'gl_Position = Pmatrix*Vmatrix*Mmatrix*vec4(position, 1.0);'+
	   'vColor = color;'+
	   'v_texcoord = a_texcoord;'+
	'}';

textureFragmentShaderCode = 'precision mediump float;'+
	'varying vec3 vColor;'+
	'varying vec2 v_texcoord;'+
	'uniform sampler2D u_texture;'+
	'void main(void) {'+
	   'gl_FragColor = texture2D(u_texture, v_texcoord);'+
	'}';

normalVertexShaderCode = 'attribute vec3 position;'+
	'uniform mat4 Pmatrix;'+
	'uniform mat4 Vmatrix;'+
	'uniform mat4 Mmatrix;'+
	'attribute vec3 color;'+//the color of the point
	'varying vec3 vColor;'+

	'void main(void) { '+
	   'gl_Position = Pmatrix*Vmatrix*Mmatrix*vec4(position, 1.0);'+  //
	   'vColor = color;'+
	'}';

normalFragmentShaderCode = 'precision mediump float;'+
	'varying vec3 vColor;'+
	'void main(void) {'+
	   'gl_FragColor = vec4(vColor, 1.0);'+
	'}';
	
function createBuffers(object, gl) {
	
	if(object.hasTexture){
		//invert y texture coordinate value.
		for(var i=1; i<object.texture_cord_size; i=i+2){
			object.array_texture_cord[i]=1-object.array_texture_cord[i];
		}
	}
	// Create and store data into vertex buffer
	object.vertex_buffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, object.vertex_buffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(object.array_vertices), gl.STATIC_DRAW);

	if(object.hasTexture){
		// Create and store data into texture buffer
		object.texture_cord_buffer = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, object.texture_cord_buffer);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(object.array_texture_cord), gl.STATIC_DRAW);
	}
	// Create and store data into color buffer
	object.color_buffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, object.color_buffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(object.array_colors), gl.STATIC_DRAW);

	// Create and store data into index buffer
	object.index_buffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, object.index_buffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(object.array_indices), gl.STATIC_DRAW);
										  
}
function createShaders(object, gl) {
	
	if(object.hasTexture){
		object.vertShaderCode=textureVertexShaderCode;
		object.fragShaderCode=textureFragmentShaderCode;
	}else{
		object.vertShaderCode=normalVertexShaderCode;
		object.fragShaderCode=normalFragmentShaderCode;
	}

	object.vertShader = gl.createShader(gl.VERTEX_SHADER);
	gl.shaderSource(object.vertShader, object.vertShaderCode);
	gl.compileShader(object.vertShader);

	object.fragShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(object.fragShader, object.fragShaderCode);
	gl.compileShader(object.fragShader);

	object.shaderProgram = gl.createProgram();
	gl.attachShader(object.shaderProgram, object.vertShader);
	gl.attachShader(object.shaderProgram, object.fragShader);
	gl.linkProgram(object.shaderProgram);
	
}
		
function loadTexture(object, gl, textureImageFilePath){
	
	object.texture = gl.createTexture();
	gl.bindTexture(gl.TEXTURE_2D, object.texture);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE,
				  new Uint8Array([255, 155, 0, 255]));
	 
	// Asynchronously load an image
	object.image = new Image();
	object.image.src = textureImageFilePath;
	object.image.addEventListener('load', function() {
		
	  gl.bindTexture(gl.TEXTURE_2D, object.texture);
	  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA,gl.UNSIGNED_BYTE, object.image);
	  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
	  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
	  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
	  gl.generateMipmap(gl.TEXTURE_2D);

	});
}

function setAttributeAndUniformLocations(object){
	
	//Associating attributes and uniforms to vertex and fragment shaders
	
	//attributes
	gl.bindBuffer(gl.ARRAY_BUFFER, object.vertex_buffer);
	object.aLoc_Position = gl.getAttribLocation(object.shaderProgram, "position");
	gl.vertexAttribPointer(object.aLoc_Position, 3, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(object.aLoc_Position);
	
	if(object.hasTexture){
		gl.bindBuffer(gl.ARRAY_BUFFER, object.texture_cord_buffer);
		object.aLoc_TexCoord = gl.getAttribLocation(object.shaderProgram, "a_texcoord");
		gl.vertexAttribPointer(object.aLoc_TexCoord , 2, gl.FLOAT, false, 0, 0);
		gl.enableVertexAttribArray(object.aLoc_TexCoord);
		
		gl.activeTexture(gl.TEXTURE0+object.texture_unit);
		gl.bindTexture(gl.TEXTURE_2D, object.texture);
	}
	
	gl.bindBuffer(gl.ARRAY_BUFFER, object.color_buffer);
	object.aLoc_Color = gl.getAttribLocation(object.shaderProgram, "color");
	gl.vertexAttribPointer(object.aLoc_Color, 3, gl.FLOAT, false,0,0);
	gl.enableVertexAttribArray(object.aLoc_Color);

	//uniforms
	object.uLoc_Pmatrix = gl.getUniformLocation(object.shaderProgram, "Pmatrix");
	object.uLoc_Vmatrix = gl.getUniformLocation(object.shaderProgram, "Vmatrix");
	object.uLoc_Mmatrix = gl.getUniformLocation(object.shaderProgram, "Mmatrix");
	
	if(object.hasTexture){
		object.uLoc_uTexture = gl.getUniformLocation(object.shaderProgram, "u_texture");
	}
	
}
