var content=[];
var obj1=["dustbin.obj","cube02.obj","tv.obj"];

function loadFileAsync(){
	for(var i=0;i<obj1.length;i++){
		$.ajax({url: obj1[i],async: false, success: function(result){
			content[i]=result;
		}});	
	}
}

function getObject(a){
	var obj=getOBJECT_Structure();

	var part96=[];
	var textures_faces=[];
	var normal_faces=[];
	var vertices_faces=[];
	var oldvertices=[];
	var oldtextures=[];
	var oldnormals=[];

	//vertices
	var part21 = "v ";
	var part22 = "vt ";
	var start=content[a].indexOf(part21);	
	var part1=content[a].slice(start + part21.length)
	var part11=part1.indexOf(part22);
	var part12=part1.slice(0,part11);	
	var part13=part12.split(/v */g);
	var part46=part13.join("");
	var part15=part46.split(/\n/g);
	
	//faces
	var part24 = "f ";
	var part16=part1.indexOf(part24);
	var part17=part1.slice(part16 + part24.length);
	var part18=part17.split(/f /g); 
	var part19=part18.join(" ");
	var part20=part19.split(" ");
	for (var j=0;j<part20.length;j++)
	{
		part96=part20[j].split("/");
		vertices_faces[j]=part96[0] - 1;
		textures_faces[j]=part96[1] - 1;
		normal_faces[j]=part96[2] - 1;
	}
	
	var y=0,x=0;
	for (x=0;x<vertices_faces.length;x++)
	{
		for(var z=0;z< part15.length-1;z++)
		{
			if(z==vertices_faces[x])
			{
				oldvertices[y]=part15[z];
				y++;
				break;
			}			
		}		
	}
	
	//normals
	var part23 = "vn ";
	var part31=part1.indexOf(part22);
	var part32=part1.slice(part31 + part22.length);
	var part33=part32.indexOf(part23);
	var part34=part32.slice(0,part33);
	var part35=part34.split(/vt */g); 
	var part36=part35.join("");
	var part37=part36.split(/\n/g);	
	
	var b=0;
	for (var a=0;a<textures_faces.length;a++)
	{
		for(var j=0;j<part37.length-1;j++)
		{
			if(j==textures_faces[a])
			{
				oldtextures[b]=part37[j];
				b++;
				break;
			}			
		}		
	}
	
	//texture
	var part25 = "usemtl";
	var part41=part32.indexOf(part23);
	var part42=part32.slice(part41 + part23.length);
	var part43=part42.indexOf(part25);
	var part44=part42.slice(0,part43);
	var part45=part44.split(/vn */g); 
	var part46=part45.join("");
	var part47=part46.split(/\n/g);
	
	var q=0;
	for (var p=0;p<normal_faces.length;p++)
	{
		for(var c=0;c<part47.length-1;c++)
		{
			if(c==normal_faces[p])
			{
				oldnormals[q]=part47[c];
				q++;
				break;
			}			
		}		
	}
	
	for(var i=0;i<vertices_faces.length;i++)
	{
		obj.array_indices[i]=i;
	}

	var part52=oldvertices.join(" ");
	var part53=part52.split(" ");

	for(var k=0;k<part53.length;k++)
	{	
		obj.array_vertices[k]=parseFloat(part53[k]);
		if(k%3 == 0)
			obj.array_colors[k]=1;
		else 
			obj.array_colors[k]=0;
	}
	var part54=oldtextures.join(" ");
	var part55=part54.split(" ");
	
	for(var j=0;j<part55.length;j++)
	{
		obj.array_texture_cord[j]=parseFloat(part55[j]);
	}

	obj.texture_cord_size=obj.array_texture_cord.length;

	var part56=oldnormals.join(" ");
	var part57=part56.split(" ");
	
	for(var c=0;c<part57.length;c++)
	{
		obj.array_normals[c]=parseFloat(part57[c]);
	}
	return obj;
}


function getOBJECT_Structure(){
	
	var OBJECT_Structure = {
		array_vertices: [],
		array_colors: [],
		array_indices: [],
		array_texture_cord: [],
		array_normals: [],
		texture_cord_size: 0,
		vertex_buffer: null,
		texture_cord_buffer: null,
		color_buffer: null,
		index_buffer: null,
		texture: null,
		texture_unit: null,
		image: null,
		mod_matrix: 
		[1,0,0,0, 
		0,1,0,0, 
		0,0,1,0, 
		-3.5,-3,0,1], //identity matrix.

		vertShaderCode: null,
		fragShaderCode: null,
		vertShader: null,
		fragShader: null,
		shaderProgram: null,
		uLoc_Pmatrix: null,
		uLoc_Vmatrix: null,
		uLoc_Mmatrix: null,
		uLoc_uTexture: null,
		aLoc_Position: null,
		aLoc_TexCoord: null,
		aLoc_Color: null,
		hasTexture: true,
	};
	
	return OBJECT_Structure;

}