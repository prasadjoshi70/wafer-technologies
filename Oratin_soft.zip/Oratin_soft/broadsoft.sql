-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2013 at 08:32 AM
-- Server version: 5.5.8-log
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `broadsoft`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmaterial`
--

CREATE TABLE IF NOT EXISTS `addmaterial` (
  `item_id` int(5) NOT NULL AUTO_INCREMENT,
  `item_name` text NOT NULL,
  `Interms` text NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10015 ;

--
-- Dumping data for table `addmaterial`
--

INSERT INTO `addmaterial` (`item_id`, `item_name`, `Interms`) VALUES
(10010, 'RJ Connector', 'number'),
(10011, 'Switch', 'number'),
(10012, 'Router', 'kg'),
(10013, 'Ethernet cable 5', 'meter');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_type` text NOT NULL,
  `date` text NOT NULL,
  `security_question` text NOT NULL,
  `security_ansure` text NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1004 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_type`, `date`, `security_question`, `security_ansure`) VALUES
(1001, 'Super', '2013/03/17', 'Birthday', '18'),
(1002, 'Limited', '2013/04/12', 'Best Friend', 'harish'),
(1003, 'Limited', '2013/04/15', 'Birthday', '20');

-- --------------------------------------------------------

--
-- Table structure for table `admincom`
--

CREATE TABLE IF NOT EXISTS `admincom` (
  `admincom_id` int(80) NOT NULL AUTO_INCREMENT,
  `admin_comment` text NOT NULL,
  `time` varchar(80) NOT NULL,
  `date` varchar(50) NOT NULL,
  `admin` varchar(50) NOT NULL,
  PRIMARY KEY (`admincom_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admincom`
--

INSERT INTO `admincom` (`admincom_id`, `admin_comment`, `time`, `date`, `admin`) VALUES
(1, 'oeifjoewi', ' 02:51', '19/03/13', 'admin'),
(2, 'iuierd', ' 07:39', '21/03/13', 'admin'),
(3, 'hsdfgeyr', ' 08:19', '15/04/13', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attend`
--

CREATE TABLE IF NOT EXISTS `attend` (
  `emp_id` int(11) NOT NULL,
  `date` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attend`
--

INSERT INTO `attend` (`emp_id`, `date`, `status`) VALUES
(100, '12/04/2013', 'Attended'),
(100, '13/04/2013', 'Attended'),
(101, '13/04/2013', 'Attended'),
(100, '15/04/2013', 'Attended');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `brandid` int(5) NOT NULL AUTO_INCREMENT,
  `brandname` text NOT NULL,
  PRIMARY KEY (`brandid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1013 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brandid`, `brandname`) VALUES
(1010, 'Dlink'),
(1011, 'Optilink'),
(1012, 'Ethernet');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE IF NOT EXISTS `complain` (
  `E_id` int(80) NOT NULL AUTO_INCREMENT,
  `Cust_id` int(50) NOT NULL,
  `order_no` int(50) NOT NULL,
  `Cust_LastName` text NOT NULL,
  `Cust_MiddleName` text NOT NULL,
  `Cust_FirstName` text NOT NULL,
  `Cust_emailid` varchar(80) NOT NULL,
  `cust_propic` varchar(50) NOT NULL,
  `problem` text NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `admin` varchar(50) NOT NULL,
  PRIMARY KEY (`E_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`E_id`, `Cust_id`, `order_no`, `Cust_LastName`, `Cust_MiddleName`, `Cust_FirstName`, `Cust_emailid`, `cust_propic`, `problem`, `time`, `date`, `admin`) VALUES
(55, 100001, 1000001, 'maq ', 'm ', 'alb', 'al@gmail.com', 'sankesh.jpg', 'jsehgrfuwebie ufyg uwefyhuuucjsbg gweuhsbjhafb uwegfuvdhgb eghejhd', ' 06:29', '15/04/13', 'admin'),
(56, 100001, 1000001, 'maq ', 'm ', 'alb', 'al@gmail.com', 'ashwin.jpg', 'ehfgwejhgj', ' 06:32', '15/04/13', 'admin'),
(57, 100004, 1000004, 'as', 'asf', 'asc', 'gg@gmail.com', 'divyesh.jpg', 'shdfgseh', ' 08:17', '15/04/13', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `connection_plan`
--

CREATE TABLE IF NOT EXISTS `connection_plan` (
  `ConnectionId` int(11) NOT NULL,
  `PlanId` int(11) NOT NULL,
  PRIMARY KEY (`PlanId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connection_plan`
--

INSERT INTO `connection_plan` (`ConnectionId`, `PlanId`) VALUES
(1, 10001),
(2, 10002),
(2, 10003),
(1, 10004);

-- --------------------------------------------------------

--
-- Table structure for table `con_type`
--

CREATE TABLE IF NOT EXISTS `con_type` (
  `ConnectionID` int(10) NOT NULL,
  `ConnectionType` text NOT NULL,
  PRIMARY KEY (`ConnectionID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `con_type`
--

INSERT INTO `con_type` (`ConnectionID`, `ConnectionType`) VALUES
(1, 'Ethernet cabel'),
(2, 'Wireless');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cust_id` int(11) NOT NULL,
  `nationality` text NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `nationality`) VALUES
(100001, 'Indian'),
(100002, 'Indian'),
(100003, 'Indian'),
(100004, 'Indian');

-- --------------------------------------------------------

--
-- Table structure for table `customer_info`
--

CREATE TABLE IF NOT EXISTS `customer_info` (
  `cust_id` int(10) NOT NULL,
  `f_name` text NOT NULL,
  `m_name` text NOT NULL,
  `l_name` text NOT NULL,
  `nationality` text NOT NULL,
  `gender` text NOT NULL,
  `address` text NOT NULL,
  `phone_no` text NOT NULL,
  `email_id` text NOT NULL,
  `plan` text NOT NULL,
  `modeofpay` text NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_of_joined` text NOT NULL,
  `security_question` text NOT NULL,
  `security_answer` text NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `date_of_joined`, `security_question`, `security_answer`) VALUES
(100, '11/04/2013', 'Birthday', '28'),
(101, '26/04/2013', 'Birthday', '10');

-- --------------------------------------------------------

--
-- Table structure for table `emp_leave`
--

CREATE TABLE IF NOT EXISTS `emp_leave` (
  `leave_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `date_of_leave` text NOT NULL,
  `to_date` text NOT NULL,
  `no_of_leave` text NOT NULL,
  `remaining_leave` text NOT NULL,
  `total_leave` text NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leave`
--

INSERT INTO `emp_leave` (`leave_id`, `emp_id`, `date_of_leave`, `to_date`, `no_of_leave`, `remaining_leave`, `total_leave`) VALUES
(100001, 101, '11/04/2013', '19/04/2013', '2', '18', '20'),
(100002, 100, '2013/04/27', '2013/04/30', '3', '17', '20'),
(100003, 100, '2013/04/16', '2013/04/19', '3', '14', '20'),
(100004, 100, '2013/04/16', '2013/04/19', '3', '11', '20');

-- --------------------------------------------------------

--
-- Table structure for table `feasibility`
--

CREATE TABLE IF NOT EXISTS `feasibility` (
  `order_no` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `date` text NOT NULL,
  `Materials` text NOT NULL,
  `quantity` text NOT NULL,
  `task` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feasibility`
--

INSERT INTO `feasibility` (`order_no`, `cust_id`, `date`, `Materials`, `quantity`, `task`) VALUES
(1000001, 100001, ' 15/04/2013 ', 'RJ Connector, Switch, ', '10, 10, ', 'Resolved'),
(1000002, 100002, ' 15/04/2013 ', 'RJ Connector,Ethernet cable 5,', '10,5,', 'In Progress'),
(1000003, 100003, ' 15/04/2013 ', 'RJ Connector, Router, ', '5, 2, ', 'In Progress'),
(1000004, 100004, ' 15/04/2013 ', 'Switch,Router,RJ Connector,', '2,10,10,', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE IF NOT EXISTS `features` (
  `features_id` int(50) NOT NULL AUTO_INCREMENT,
  `feature_title` text NOT NULL,
  `features` text NOT NULL,
  `features_pic` varchar(50) NOT NULL,
  `admin` text NOT NULL,
  PRIMARY KEY (`features_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`features_id`, `feature_title`, `features`, `features_pic`, `admin`) VALUES
(2, 'Content Filtering', 'Content Filtering enables organizations to block access to unproductive, malware-infacted websites that may expose them to legal liabilities or drain corporate resources.', '1.jpg', 'admin'),
(4, 'Unified Threat Management', 'Unified Threat Management solution provides comprehensive protection to organizations with tightly integrated multiple security features working together on a single appliance.', '3.jpg', 'admin'),
(5, 'Identity-Based Policies', 'Identity-based UTM that tells you who is accessing what resources in the network. Its Intrusion Prevention system allows use identity-based policies that can block file transfer over P2P and IM applications.', '4.jpg', 'admin'),
(6, 'Low Cost â€œPlug-and-Playâ€ Security', 'Low cost â€œplug-and-playâ€ security. It eliminates the need formultiple maintenance contracts for multiple solutions and trained technical personnel for complex installations.', 'hhh.jpg', 'admin'),
(7, 'Multi-Link Management', 'Multi-Link Management transfers traffic from a failed link to a working link automatically for dependable, seamless connectivity. This ensures mission-critical applications like CRM, VoIP, and more do not suffer.', '6.jpg', 'admin'),
(9, 'Bandwidth Management', 'Bandwidth Management prioritizes bandwidth allocation for users, groups and applications based on usage and time of the day. complementing it is Ethernet Xpressâ€™s content Filtering that blocks access to high Bandwidth-consuming Audio-Visual downloads, gaming, ads and more', '8.jpg', 'admin'),
(10, 'Gateway Anti-Virus Spyware', 'ieyr8bry 8 ry874yr473 3723e73eer73r37ry3ryetryedgc dgcygyefgceyrfgyegajuyewgf r g4uyrgyugwsac yerfgye', '9.jpg', 'admin'),
(11, 'djfhgb', 'jshdfbehjfbj', 'DSCN8169.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `involves`
--

CREATE TABLE IF NOT EXISTS `involves` (
  `order_no` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `ConnectionID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  UNIQUE KEY `order_no` (`order_no`,`cust_id`,`ConnectionID`,`PlanID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `involves`
--

INSERT INTO `involves` (`order_no`, `cust_id`, `ConnectionID`, `PlanID`) VALUES
(1000001, 100001, 2, 10002),
(1000002, 100002, 1, 10003),
(1000003, 100003, 2, 10002),
(1000004, 100004, 1, 10003);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE IF NOT EXISTS `material` (
  `ItemId` int(10) NOT NULL AUTO_INCREMENT,
  `SellerName` text NOT NULL,
  `Brand` text NOT NULL,
  `ItemName` text NOT NULL,
  `Quantity` int(10) NOT NULL,
  `UnitPrice` int(10) NOT NULL,
  `Discount` int(10) NOT NULL,
  `TotalPrice` int(20) NOT NULL,
  `Remark` text,
  `date` text NOT NULL,
  PRIMARY KEY (`ItemId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1107 ;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`ItemId`, `SellerName`, `Brand`, `ItemName`, `Quantity`, `UnitPrice`, `Discount`, `TotalPrice`, `Remark`, `date`) VALUES
(1101, 'prasad', 'Dlink', 'RJ Connector', 100, 20, 0, 2000, 'some are defected', '2013/04/12'),
(1102, 'ganesh', 'Dlink', 'Switch', 50, 13, 5, 618, 'gud', '2013/04/12'),
(1103, 'sad', 'Dlink', 'RJ Connector', 52, 2, 0, 104, 'all are gud in condition', '2013/04/13'),
(1104, 'sid', 'Optilink', 'Router', 30, 5, 0, 150, 'gud', '2013/04/13'),
(1105, 'raghvendra', 'Ethernet', 'Ethernet cable 5', 5000, 5, 5, 23750, 'ok', '2013/04/15'),
(1106, 'ddd', 'Optilink', 'Switch', 55, 64, 5, 3344, 'good', '2013/04/15');

-- --------------------------------------------------------

--
-- Table structure for table `materialoperation`
--

CREATE TABLE IF NOT EXISTS `materialoperation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL,
  `Materials` text NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11010 ;

--
-- Dumping data for table `materialoperation`
--

INSERT INTO `materialoperation` (`id`, `order_no`, `Materials`, `qty`) VALUES
(11001, 1000001, 'RJ Connector', 10),
(11002, 1000001, 'Switch', 10),
(11003, 1000002, 'RJ Connector', 10),
(11004, 1000003, 'RJ Connector', 10),
(11005, 1000003, 'Router', 2),
(11006, 1000002, 'Ethernet cable 5', 5),
(11007, 1000004, 'Switch', 2),
(11008, 1000004, 'Router', 10),
(11009, 1000004, 'RJ Connector', 10);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `mess` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mess`) VALUES
('\r\nFor Id  1000001 - why it is steel in progress\r\nSun  14.04.2013 10:35:12      By vipul\r\n\r\nFor Id  1000001 - some problem occured in placement....\r\nMon  15.04.2013 12:11:38      By prasad(LR)\r\n\n\nFor Id  1000002 - kk solved it fast..\nMon  15.04.2013 12:22:33      By Raghven(SR)\n\nFor Id  1000002 - kk gud...\nMon  15.04.2013 12:25:16      By prasad(LR)\n\nFor Id  1000004 - kk not available material\nMon  15.04.2013 01:30:39      By Raghven(SR)\n\nFor Id  1000004 - ok\nMon  15.04.2013 01:31:45      By vipul\n\nFor Id  1000003 - done\nMon  15.04.2013 01:38:48      By prasad(LR)');

-- --------------------------------------------------------

--
-- Table structure for table `nationality`
--

CREATE TABLE IF NOT EXISTS `nationality` (
  `nid` int(5) NOT NULL AUTO_INCREMENT,
  `nname` text NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1113 ;

--
-- Dumping data for table `nationality`
--

INSERT INTO `nationality` (`nid`, `nname`) VALUES
(1111, 'Indian'),
(1112, 'Pakistan');

-- --------------------------------------------------------

--
-- Table structure for table `order_cust`
--

CREATE TABLE IF NOT EXISTS `order_cust` (
  `order_no` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `date` text NOT NULL,
  `instalment_amt` int(11) NOT NULL,
  `total_amt` int(11) NOT NULL,
  `cheque_no` text NOT NULL,
  `others` text NOT NULL,
  `bank_name` text NOT NULL,
  `cheque_date` text NOT NULL,
  `amt` int(11) NOT NULL,
  PRIMARY KEY (`order_no`),
  UNIQUE KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_cust`
--

INSERT INTO `order_cust` (`order_no`, `cust_id`, `date`, `instalment_amt`, `total_amt`, `cheque_no`, `others`, `bank_name`, `cheque_date`, `amt`) VALUES
(1000001, 100001, '13/04/2013', 200, 400, '', 'cash', '', '', 600),
(1000002, 100002, '2013/04/15', 200, 400, '', 'cash', '', '', 600),
(1000003, 100003, '2013/04/15', 1000, 400, '', 'cash', '', '', 1400),
(1000004, 100004, '2013/04/15', 200, 200, '', 'cash', '', '', 400);

-- --------------------------------------------------------

--
-- Table structure for table `plan_type`
--

CREATE TABLE IF NOT EXISTS `plan_type` (
  `PlanID` int(10) NOT NULL,
  `PlanType` text NOT NULL,
  `Price` int(10) NOT NULL,
  PRIMARY KEY (`PlanID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plan_type`
--

INSERT INTO `plan_type` (`PlanID`, `PlanType`, `Price`) VALUES
(10001, '9 month plan', 250),
(10002, '5 month plan', 120),
(10003, '9 month plan', 400),
(10004, '2 month plan', 200);

-- --------------------------------------------------------

--
-- Table structure for table `retrive`
--

CREATE TABLE IF NOT EXISTS `retrive` (
  `name` text NOT NULL,
  `ename` text NOT NULL,
  `type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retrive`
--

INSERT INTO `retrive` (`name`, `ename`, `type`) VALUES
('prasad', 'vipul', 'Limited');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `item_id` int(5) NOT NULL,
  `item_name` text NOT NULL,
  `total_quantity` text,
  `quantity_sold` text,
  `quantity_rema` text,
  `remark` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`item_id`, `item_name`, `total_quantity`, `quantity_sold`, `quantity_rema`, `remark`) VALUES
(10010, 'RJ Connector', '152', '30', '122', 'all are gud in condition'),
(10011, 'Switch', '105', '12', '93', 'good'),
(10012, 'Router', '30', '10', '18', 'gud'),
(10013, 'Ethernet cable 5', '5000', '5', '4995', 'ok');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text NOT NULL,
  `last_name` text NOT NULL,
  `gender` text NOT NULL,
  `email_id` text NOT NULL,
  `ph_no` text NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_type`, `username`, `password`, `first_name`, `middle_name`, `last_name`, `gender`, `email_id`, `ph_no`, `address`, `image`) VALUES
(100, 'emp', 'gautam', 'gautam', 'gautam', 'm', 'naik', 'Male', 'g@gmail.com', '8005422212', 'mapus', 'gautam.jpg'),
(101, 'emp', 'vipul', 'vipul1', 'vipul', 'a', 'yende', 'Male', 'v@gmail.com', '9637567625', 'mapusa', 'pritesh.jpg'),
(1001, 'admin', 'Raghven', 'raghven', 'raghven', 'm', 'naik', 'null', 'null', 'null', 'null', 'raghven.jpg'),
(1002, 'admin', 'prasad', 'prasad', 'prasad', 'm', 'joshi', 'null', 'null', 'null', 'null', 'prasad.jpg'),
(1003, 'admin', 'ratish', 'ratish', 'ratish', 'mm', 'naik', 'null', 'null', 'null', 'null', ''),
(100001, 'cust', 'albrito', 'aaa', 'alb', 'm ', 'maq ', 'Male', 'al@gmail.com', '6546546546 ', 'mapusa', 'ashwin.jpg'),
(100002, 'cust', 'null', 'null', 'ganesh', 'r', 'patkar', 'Male', 'a@gmail.com', '9823840527', 'colvalim', ''),
(100003, 'cust', 'null', 'null', 'amit', 'a', 'acg', 'Male', 'amit@gmail.com', '9876543212', 'sda', ''),
(100004, 'cust', 'ganesh', 'ggg', 'asc', 'asf', 'as', 'Male', 'gg@gmail.com', '6546541654', 'mp', 'divyesh.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
