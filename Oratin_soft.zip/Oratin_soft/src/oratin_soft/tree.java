package oratin_soft;
 
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
 

public class tree {
 
    static String lastComponent = "";
 
    public static void main(String[] args) {
          try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        final JFrame jf = new JFrame("Practice Applications");
 
        DefaultMutableTreeNode pracApps = new DefaultMutableTreeNode("Practice Apps", true);
        DefaultMutableTreeNode calc = new DefaultMutableTreeNode("Calculator");
        DefaultMutableTreeNode fact = new DefaultMutableTreeNode("Factorial");
        DefaultMutableTreeNode temperature = new DefaultMutableTreeNode("Temperature", true);
        DefaultMutableTreeNode c2f = new DefaultMutableTreeNode("C to F");
        DefaultMutableTreeNode f2c = new DefaultMutableTreeNode("F to C");
        temperature.add(c2f);
        temperature.add(f2c);
        pracApps.add(calc);
        pracApps.add(fact);
        pracApps.add(temperature);
        final JTree tree = new JTree(pracApps);
 
        // JTree here can act as a menu for Practice Applications
        // We add it on the west side of the JFrame
 
        jf.add(BorderLayout.WEST, tree);
 
        
////        final Calc calculatorPanel = new Calc();
////        final Factorial factorialPanel = new Factorial();
      
        JButton b=new JButton("ok");
       final JPanel p=new JPanel();
       p.add(b);
       
      
       
////        final C2F c2fObj = new C2F();
////        final F2C f2cObj = new F2C();
 
        // Lets change the panel on center of JFrame
        // by checking the mouse click
        tree.addMouseListener(new MouseAdapter() {
 
            @Override
            public void mouseClicked(MouseEvent me) {
                TreePath path = tree.getPathForLocation(me.getX(), me.getY());
                if (path != null) {
                    // Check the last added component and remove it
                    if (!lastComponent.equals("")) {
                        if (lastComponent.equals("Factorial")) {
                            jf.remove(p);
                        }
                    }
 
                    // Add the new component on the frame
                    // Depending on the Selected Tree Node
                    if (path.toString().contains("Calculator")) {
                      jf.add(p);
                        lastComponent = "Calculator";
                    }
                    jf.repaint();
                }
            }
        });
        jf.setSize(600, 400);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);
    }
}