/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package oratin_soft;


import java.awt.Color;
import java.awt.Container;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Comp
 */
public class Physibility_operation extends javax.swing.JFrame {

    Connection con;
    ResultSet rs,rs1,rs2;
    Statement stat;
    Container c;
    public int diff;
    public String mm="";
    public String tp = "";
     public String tq = "";
    public String tm = "";
    public String tn = "";
      public String n = "";
      
          public String before = "";
      public String after = "";
    public int k;
    String a;
    DefaultTableModel model, model1;
    Vector vec1, vec2;
    String data[][] = {};
    String col[] = {"Materials", "Quantity"};
    String data1[][] = {};
    String col1[] = {"Order_id", "Cust_id","First_name","Middle_name","Last_name","Address", "Plan_choosen", "Connction_type", "Materials", "Qty", "Task"};

    public Physibility_operation() {
        initComponents();
        vec1 = new Vector();
        model = new DefaultTableModel(data, col);

        vec2 = new Vector();
        model1 = new DefaultTableModel(data1, col1);

        Date now = new Date();
        // Use SimpleDateFormat
        SimpleDateFormat simpleFormatter = new SimpleDateFormat(" dd.MM.yyyy ");
        ConnectionType();
       
        Select_Material();
        increment1();
   
        refresh();
         jLabel14.setVisible(false);
        jTextField16.setVisible(false);
                jLabel2.setVisible(false);
                   jLabel5.setVisible(false);
                    jLabel7.setVisible(false);
                     jLabel10.setVisible(false);
                       jLabel13.setVisible(false);
                      jLabel6.setVisible(false);
                jLabel3.setVisible(false);      
                jLabel4.setVisible(false);
                
                
      jButton2.setEnabled(false); 
                
        jTextField5.setVisible(false);
        jTextField7.setVisible(false);
        jTextField13.setVisible(false);
          jTextField15.setEnabled(false);
        jTextField9.setVisible(false);
        jTextField12.setVisible(false);
        jTextField17.setVisible(false);
        jTextField16.setVisible(false);
        jTextField2.setVisible(false);
        jTextField3.setVisible(false);
        jTextField14.setVisible(false);
       jLabel1.setVisible(false);
        jTable1.setEnabled(false);

        jTextField14.setEnabled(false);
        jComboBox1.setEnabled(false);
         jComboBox3.setEnabled(false);
        jComboBox2.setEnabled(false);
        jTextField11.setEnabled(false);
        jRadioButton1.setEnabled(false);
        jRadioButton2.setEnabled(false);
        jRadioButton3.setEnabled(false);
        jRadioButton4.setEnabled(false);
        jRadioButton5.setEnabled(false);

        jButton1.setEnabled(false);
        jButton2.setEnabled(false);
        jButton3.setEnabled(false);
        jButton7.setEnabled(false);


        jLabel9.setEnabled(false);

        jLabel11.setEnabled(false);

        jLabel12.setEnabled(false);
jTextField11.setVisible(false);
        jLabel15.setEnabled(false);
          jButton1.setVisible(false);
            jLabel16.setVisible(false);
    }

    public void ConnectionType() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from con_type");

            // jComboBox1.removeAllItems(); 
            while (rs.next()) {
                jComboBox1.addItem(rs.getString(2));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void Select_Material() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from addmaterial");

            // jComboBox1.removeAllItems(); 
            while (rs.next()) {
                jComboBox2.addItem(rs.getString(2));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }
 public void Select_Material_check() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from materialoperation where order_no='"+jTextField14.getText()+"' and Materials='"+jComboBox2.getSelectedItem().toString()+"'");

            // jComboBox1.removeAllItems(); 
            while (rs.next()) {
                  n = rs.getString(3).toString();
                  System.out.println(n);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jToolBar1 = new javax.swing.JToolBar();
        jButton4 = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        jButton5 = new javax.swing.JButton();
        jTextField11 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true), "Feasibility Maintainance", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 0, 16), new java.awt.Color(0, 102, 102))); // NOI18N

        jTable1.setBackground(new java.awt.Color(153, 153, 153));
        jTable1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(102, 102, 102));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("Connection Type");

        jComboBox1.setBackground(new java.awt.Color(102, 102, 255));
        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select Connection" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("Plans");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Materials");

        jComboBox2.setBackground(new java.awt.Color(102, 102, 255));
        jComboBox2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select Materials" }));
        jComboBox2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jComboBox2MouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox2MouseClicked(evt);
            }
        });
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jComboBox2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jComboBox2FocusGained(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(1, 70, 104));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 204, 204));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconax/images/sdf (2).png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 51, 51));
        jLabel15.setText("Task");

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(51, 51, 51));
        jRadioButton1.setText("Assigned");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(51, 51, 51));
        jRadioButton2.setText("In Progress");

        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jRadioButton3.setForeground(new java.awt.Color(51, 51, 51));
        jRadioButton3.setText("Resolved");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jRadioButton4.setForeground(new java.awt.Color(51, 51, 51));
        jRadioButton4.setText("On Hold");

        buttonGroup1.add(jRadioButton5);
        jRadioButton5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jRadioButton5.setForeground(new java.awt.Color(51, 51, 51));
        jRadioButton5.setText("Cancelled");
        jRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton5ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(1, 70, 104));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(204, 204, 204));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconax/buttonimage/save.png"))); // NOI18N
        jButton2.setText("SAVE");
        jButton2.setIconTextGap(8);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                jLabel8CaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
            }
        });

        jTextField15.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTextField15CaretUpdate(evt);
            }
        });
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(1, 70, 104));
        jButton3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(204, 204, 204));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconax/buttonimage/deee.png"))); // NOI18N
        jButton3.setText("DELETE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(1, 70, 104));
        jButton7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(204, 204, 204));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconax/buttonimage/ed.png"))); // NOI18N
        jButton7.setText("UPDATE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jComboBox3.setBackground(new java.awt.Color(102, 102, 255));
        jComboBox3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select plan" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 102, 0));
        jLabel16.setText("jLabel7");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton3)
                                    .addComponent(jRadioButton1)
                                    .addComponent(jRadioButton4))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton5)
                                    .addComponent(jRadioButton2)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox1, 0, 230, Short.MAX_VALUE)
                                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField15))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(63, 63, 63))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel8)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jRadioButton5))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jRadioButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jRadioButton3)
                                    .addComponent(jRadioButton2)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRadioButton4)))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(115, 115, 115)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable3.setBackground(new java.awt.Color(153, 153, 153));
        jTable3.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable3.setSelectionBackground(new java.awt.Color(102, 102, 102));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("Note : Select order from the table");

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("Note : Select  from table to update or delete materials");

        jLabel5.setText("jLabel5");

        jLabel6.setText("jLabel5");

        jLabel7.setText("jLabel7");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 0, 0));
        jLabel10.setText("jLabel7");

        jLabel13.setText("jLabel7");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 153, 0));
        jLabel14.setText("jLabel7");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(65, 65, 65)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(196, 196, 196)
                .addComponent(jLabel18)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel19)
                        .addComponent(jLabel5)
                        .addComponent(jLabel6)
                        .addComponent(jLabel7)
                        .addComponent(jLabel10)
                        .addComponent(jLabel13)
                        .addComponent(jLabel14)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(37, 37, 37))
        );

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 102, 102));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconax/images/home.png"))); // NOI18N
        jLabel20.setText("Home");
        jLabel20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel20.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        jTextField14.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTextField14CaretUpdate(evt);
            }
        });

        jToolBar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true));
        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);
        jToolBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jToolBar1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton4.setText("Feasibility Generate   ");
        jButton4.setFocusable(false);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton4);
        jToolBar1.add(jSeparator2);

        jButton5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton5.setText("Maintainance    ");
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton5);

        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jLabel2.setText("jLabel2");

        jLabel3.setText("jLabel3");

        jLabel4.setText("jLabel4");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(66, 66, 66)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4)
                                .addGap(51, 51, 51)))
                        .addComponent(jLabel20))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4))
                            .addGap(41, 41, 41)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 605, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        dispose();
        new Home().setVisible(true);
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
   // TODO add your handling code here:
 
        jLabel1.setText("");
        jTextField15.setEnabled(true);
        jComboBox2.setEnabled(true);
        int sr = jTable1.getSelectedRow();
        String id = model.getValueAt(sr, 0).toString();
        String cid = model.getValueAt(sr, 1).toString();

        jComboBox2.setSelectedItem(id);
       jTextField15.setText(cid);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from materialoperation where Materials='"+jComboBox2.getSelectedItem().toString()+"'");

          
            while (rs.next()) {
              jLabel6.setText(rs.getString(1));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from addmaterial where item_name='"+jComboBox2.getSelectedItem().toString()+"'");

          
            while (rs.next()) {
              jLabel5.setText(rs.getString(1));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
     before_qyan();
Totalretrive_calculate();
    }//GEN-LAST:event_jTable1MouseClicked
 public void add1_id() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from con_type where ConnectionType='"+jComboBox1.getSelectedItem().toString()+"'");

            // jComboBox1.removeAllItems(); 
            while (rs.next()) {
              jLabel2.setText(rs.getString(1));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }
  public void add1_id_plan() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs1 = stat.executeQuery("select * from plan_type where PlanType='"+jComboBox3.getSelectedItem().toString()+"'");

          
            while (rs1.next()) {
              jLabel3.setText(rs1.getString(1));
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
add1_id();
        refresh_plan();
        add1_id_plan(); 
        if(!jComboBox1.getSelectedItem().equals("Select Connection"))
       {
             jLabel1.setVisible(false);
           jLabel1.setText("");
       }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2MouseClicked

    private void jComboBox2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox2MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2MouseReleased

    public void mat() {

        try {
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Physibility_limited.class.getName()).log(Level.SEVERE, null, ex);
            }
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");

            stat = con.createStatement();


            String a = jTextField17.getText().toString();
            int a1 = Integer.parseInt(a);
            String b = jTextField16.getText().toString();
            int b1 = Integer.parseInt(b);

            String cust = jLabel8.getText().toString();
            String c = jTextField15.getText().toString();
            int c1 = Integer.parseInt(c);



            stat.executeUpdate("insert into materialoperation values('" + a1 + "','" + b1 + "','" + cust + "','" + c1 + "')");
  jLabel1.setVisible(true);
         
          jLabel14.setVisible(true);
        jLabel14.setText("Updated Successfully");

            increment1();
            con.close();
            stat.close();
        } catch (SQLException ex) {
            Logger.getLogger(Physibility_limited.class.getName()).log(Level.SEVERE, null, ex);
        }


    }

    public void increment1() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select max(id) from materialoperation");
            int id = 0;
            while (rs.next()) {

                id = Integer.parseInt(rs.getString(1)) + 1;
            }
            jTextField17.setEnabled(false);
            jTextField17.setText(String.valueOf(id));
            jTextField17.setEditable(false);
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in  increment" + ex);
        }

    }
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed


        String a = (String) jComboBox2.getSelectedItem();
        jLabel8.setText(a);
        if(jComboBox2.getSelectedItem().equals("Select Materials"))
        {
        jLabel8.setText("");
        }
        jTextField9.setText(jLabel8.getText());
        jTextField12.setText(", ");
        jTextField15.setText("");
          if(!jComboBox2.getSelectedItem().equals("Select Materials"))
        {
           jLabel1.setVisible(false);
            jLabel1.setText("");
        }
        Select_Material_check(); 
           if(!n.equals(jLabel8.getText()))
        {
            jButton1.setVisible(true);
              jLabel16.setVisible(false);
        }
        else{
             jButton1.setVisible(false);
             jLabel16.setVisible(true);
             jLabel16.setText("Already Added");
        } 
      
    }//GEN-LAST:event_jComboBox2ActionPerformed
    public void update_phy() {
        try {
            String dd = jComboBox2.getSelectedItem().toString();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            stat.executeUpdate("update materialoperation set qty='" + jTextField15.getText() + "'where Materials='" + jComboBox2.getSelectedItem().toString() + "'");


            con.close();
            stat.close();
        } catch (SQLException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        }




    }

    public void delete_phy() {
        try {
            String dd = jComboBox2.getSelectedItem().toString();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            stat.executeUpdate("delete from materialoperation where Materials='" + jComboBox2.getSelectedItem().toString() + "'");


            con.close();
            stat.close();
        } catch (SQLException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        }




    }

    public void update_Ophy() {
        try {
            String dd = jComboBox2.getSelectedItem().toString();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            String r = null;
            if (jRadioButton1.isSelected()) {
                r = jRadioButton1.getText();
            } else if (jRadioButton2.isSelected()) {
                r = jRadioButton2.getText();
            } else if (jRadioButton3.isSelected()) {
                r = jRadioButton3.getText();
            } else if (jRadioButton4.isSelected()) {
                r = jRadioButton4.getText();
            } else if (jRadioButton5.isSelected()) {
                r = jRadioButton5.getText();
            }
            stat.executeUpdate("update feasibility set Materials='" + jTextField2.getText() + "',quantity='" + jTextField3.getText() + "',task='" + r + "' where order_no='" + jTextField14.getText() + "'");
    stat.executeUpdate("update involves set ConnectionID='" + jLabel2.getText() + "',PlanID='" + jLabel3.getText() + "' where order_no='" + jTextField14.getText() + "'");
            
            
            jLabel14.setVisible(true);
         
                
          
        jLabel14.setText("Updated Successfully");
            con.close();
            stat.close();
        } catch (SQLException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Physibility_operation.class.getName()).log(Level.SEVERE, null, ex);
        }




    }
    public void Totalretrive_calculate() {
        String a = jTextField9.getText().toString();

      
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_id='"+jLabel5.getText()+"'");

            // jComboBox1.removeAllItems(); 


            while (rs.next()) {
                jLabel7.setText(rs.getString(5));
   jLabel13.setText(rs.getString(3));

            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        if(jLabel8.getText().equals(""))
        {
            jLabel1.setVisible(true);
              jLabel1.setText("Select the material");
            
        }  
       else if((jTextField15.getText().equals("")))
      {
            jLabel1.setVisible(true);
         
            jLabel1.setText("Enter the Qty");
           
           
      }
  
       
        
        
        String before=jLabel13.getText();
int before1=Integer.parseInt(before);
if(jLabel13.getText().equals("0"))
{
     jLabel10.setVisible(true);
            jLabel10.setText("Not have required material in stock");
}
   else
{
        
        
        String get=jLabel7.getText();
int get1=Integer.parseInt(get);
String qty=jTextField15.getText();
int qty1=Integer.parseInt(qty);
int dif=get1-qty1;
        System.out.println(dif);
        if(dif<0)
        {
            if(jLabel1.isVisible())
            {
                  jLabel10.setVisible(false);
            }
            else
            {
            jLabel10.setVisible(true);
            jLabel10.setText("Not have required material in stock");
        }
        }
        
        else{
        
        String a = jLabel8.getText();
        jTextField13.setText(jTextField15.getText());


        jTextField5.setText(jTextField5.getText() + jTextField9.getText() + jTextField12.getText());
        jTextField7.setText(jTextField7.getText() + jTextField13.getText() + jTextField12.getText());
//
        
        
      if(jComboBox2.getSelectedItem().equals("Select Materials"))
      {
          jButton1.setVisible(false);
            jLabel1.setVisible(true);
          jLabel1.setForeground(Color.red);
          jLabel1.setText("Select The Material");
      }
     else if(jTextField15.getText().equals(""))
          {
                jLabel1.setVisible(true);
              jLabel1.setForeground(Color.red);
              jLabel1.setText("Enter Quantity");
          }
      else
      {
          if(!n.equals(jLabel8.getText()))
        {
              mat();
            refresh1();
             String dd = jComboBox2.getSelectedItem().toString();
        String m = jTextField15.getText().toString();
        try {
            refreshquan_sold();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.print("Connected Successfully");
            stat = con.createStatement();

            stat.executeUpdate("update stock set quantity_sold= '" + jTextField15.getText() + "' where item_name='" + dd + "'");
          

            quansoldupdate();

            subtract();
            subtract1();
refresh();
          
           
            jLabel8.setText("");
            con.close();
            stat.close();
        } catch (Exception e11) {
            System.out.println("Error" + e11);
        }
      
        }
        
     
          else {
          
           
      


        String dd = jComboBox2.getSelectedItem().toString();
        String m = jTextField15.getText().toString();
        try {
            refreshquan_sold();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.print("Connected Successfully");
            stat = con.createStatement();

            stat.executeUpdate("update stock set quantity_sold= '" + jTextField15.getText() + "' where item_name='" + dd + "'");
          

            quansoldupdate();

            subtract();
            subtract1();
refresh();
       Totalretrive_calculate();    
        
            jLabel8.setText("");
            jButton2.setEnabled(true);
            con.close();
            stat.close();
        } catch (Exception e11) {
            System.out.println("Error" + e11);
        }
      }
      }
        }
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    public void quansoldupdate() {
        String qu = jTextField15.getText();
        int b = Integer.parseInt(qu);
        int a = Integer.parseInt(tp);
        int c = a + b;

        String n = jComboBox2.getSelectedItem().toString();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_sold='" + c + "'where item_name='" + n + "'");


            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in updating" + ex);

        }
    }

    public void subtract() {
        String a = jComboBox2.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_name='" + a + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                tm = rs.getString(3);
                int m = Integer.parseInt(tm);
                tn = rs.getString(4);
                int n = Integer.parseInt(tn);
                k = m - n;
                System.out.print(k);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void refreshquan_sold() {
        String a = jComboBox2.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_name='" + a + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                tp = rs.getString(4);
                System.out.println(tp);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void subtract1() {
        String n = jComboBox2.getSelectedItem().toString();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_rema='" + k + "'where item_name='" + n + "'");

            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in updating" + ex);

        }
    }
    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
// if (jTable3.getSelectedRow() == -1) {
//            JOptionPane.showMessageDialog(null, "select the record first");
//        }
// else  if (jTable1.getSelectedRow() == -1) {
//            jLabel1.setVisible(true);
//
//          jLabel1.setText("Select The Material");
//        }
// else
// {
        Totalretrive_calculate();
      set_perfect_value();
        update_Ophy();
         quansoldupdate();
        delete_quanstock();
                    delete_stock_update();
    
         after_qyan();
  
     
                    refresh();

        refresh1();
         

         int before1=Integer.parseInt(before);
            int after1=Integer.parseInt(after);
            diff=after1-before1;
            System.out.println("before is"+before1);
            System.out.println("after is"+after1);
            System.out.println("difference is"+diff);
            if(after1 > before1){
                retrive_quan();
                 add_update();
                 mult();
                 mult1();
                 
             }
            
//             if(before1 > after1){
//                retrive_quan1();
//                 
//                delete_update();
//                 addition();
//                 addition1();
//                 
//               //  System.out.println("prasad");
//             }
          jLabel1.setVisible(false);
         JOptionPane.showMessageDialog(rootPane, "Successfully Saved");
         jComboBox1.setSelectedItem("Select Connection");
        jComboBox1.setEnabled(false);
         jComboBox3.removeAllItems();
          jComboBox3.setEnabled(false);
        buttonGroup1.clearSelection();
         jComboBox2.setSelectedItem("Select Materials");
          jComboBox2.setEnabled(false);
         jTextField15.setText("");
          jTextField15.setEnabled(false);
          jButton1.setEnabled(false);
           jButton3.setEnabled(false);
            jButton7.setEnabled(false);
          jRadioButton1.setEnabled(false);
          jRadioButton2.setEnabled(false);
          jRadioButton3.setEnabled(false);
          jRadioButton4.setEnabled(false);
         jLabel10.setVisible(false);
         jLabel14.setVisible(false);
         jButton2.setEnabled(false);
         Totalretrive_calculate();
 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jLabel8CaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jLabel8CaretPositionChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8CaretPositionChanged

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
if (jTable3.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "select the record first", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
 else  if (jTable1.getSelectedRow() == -1) {
            jLabel1.setVisible(true);

          jLabel1.setText("Select The Material");
        }
 else {
        if(jComboBox2.getSelectedItem().equals("Select Materials"))
      {
            jLabel1.setForeground(Color.red);
          jLabel1.setText("Select The Material");
      }
      else if((jTextField15.getText().equals("")))
      {
            jLabel1.setForeground(Color.red);
            jLabel1.setText("Select The Material");
      }
      else
      {
        
        
        int option = JOptionPane.showConfirmDialog(null, "Do you want to delete", "", JOptionPane.YES_NO_CANCEL_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            delete_phy();
            refresh1();
            refresh();
 
       delete_quanstock();
                    delete_stock_update();
                     addition();
                     addition1();
       
     //   refresh1();
     
//      set_perfect_value();
//        update_Ophy();
//       
//        update_phy();
//       refresh();
//       
//       Totalretrive_calculate();
//        refresh1();
     
      jButton2.setEnabled(true); 
       
       
    
jTextField2.setText("");
jTextField3.setText(""); 
        
        }
    
    
      
    
            if (option == JOptionPane.NO_OPTION) {
            }

        

      }
 }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
 if (jTable3.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "select the record first", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
 else  if (jTable1.getSelectedRow() == -1) {
            jLabel1.setVisible(true);

          jLabel1.setText("Select The Material");
        }
 else
 {
 if(jComboBox2.getSelectedItem().equals("Select Materials"))
      {
            jLabel1.setVisible(true);
           
          
          jLabel1.setText("Select The Material");
      }
      else if((jTextField15.getText().equals("")))
      {
            jLabel1.setVisible(true);
         
            jLabel1.setText("Select The Material");
      }
      else
      {
            int sr = jTable1.getSelectedRow();
        String id = model.getValueAt(sr, 1).toString();
       
        
      String get=jLabel7.getText();
int get1=Integer.parseInt(get);
String qty=jTextField15.getText();
int qty1=Integer.parseInt(qty);
int dif=get1-qty1;
        System.out.println(dif);
        if(dif<0 && !jTextField15.getText().equals(id))
        {
            jLabel10.setVisible(true);
            jLabel10.setText("Not have required material in stock");
        }
        else{
          
          String a = jLabel8.getText();
        jTextField13.setText(jTextField15.getText());


        jTextField5.setText(jTextField5.getText() + jTextField9.getText() + jTextField12.getText());
        jTextField7.setText(jTextField7.getText() + jTextField13.getText() + jTextField12.getText());




        String dd = jComboBox2.getSelectedItem().toString();
        String m = jTextField15.getText().toString();
        try {
            refreshquan_sold();
           
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.print("Connected Successfully");
            stat = con.createStatement();

            stat.executeUpdate("update stock set quantity_sold= '" + jTextField15.getText() + "' where item_name='" + dd + "'");
           

            quansoldupdate();
              update_Ophy();
                refresh();

        refresh1();
            subtract();
               subtract1();
               after_qyan();
               jButton2.setEnabled(true);
                 jTextField2.setText("");
jTextField3.setText(""); 
          
            con.close();
            stat.close();
        } catch (Exception e11) {
            System.out.println("Error" + e11);
        }


                             
 
        set_perfect_value();
        update_Ophy();
       
        update_phy();
       refresh();
       
       Totalretrive_calculate();
        refresh1();
     
     
      jButton2.setEnabled(true); 
       
    
jTextField2.setText("");
jTextField3.setText(""); 
        
     
      }
      }
 }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField14CaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTextField14CaretUpdate
        jTextField16.setText(jTextField14.getText());
        refresh1();
    }//GEN-LAST:event_jTextField14CaretUpdate

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked

        
        jLabel9.setEnabled(true);

        jLabel11.setEnabled(true);

        jLabel12.setEnabled(true);

        jLabel15.setEnabled(true);

        jTable1.setEnabled(true);
   
        jComboBox1.setEnabled(true);
     jComboBox3.setEnabled(true);
      
        jTextField11.setEnabled(true);
        jRadioButton1.setEnabled(true);
        jRadioButton2.setEnabled(true);
        jRadioButton3.setEnabled(true);
        jRadioButton4.setEnabled(true);
        jRadioButton5.setEnabled(true);
        
        jButton1.setEnabled(true);
     // jButton2.setEnabled(true);
        jButton3.setEnabled(true);
        jButton7.setEnabled(true);

        // TODO add your handling code here:
        int sr = jTable3.getSelectedRow();
        String id = model1.getValueAt(sr, 0).toString();
        String i1 = model1.getValueAt(sr, 2).toString();
        String id1 = model1.getValueAt(sr, 3).toString();
        String id2 = model1.getValueAt(sr, 4).toString();
        String id3 = model1.getValueAt(sr, 6).toString(); 
           String id5 = model1.getValueAt(sr, 7).toString(); 
                 String i45 = model1.getValueAt(sr, 8).toString(); 
        String id4 = model1.getValueAt(sr, 10).toString();
        jTextField14.setText(id);
        jComboBox1.setSelectedItem(id1);
        jTextField11.setText(id2);

jComboBox1.setSelectedItem(id5);
jComboBox3.setSelectedItem(id3);
        if (id4.equals("Assigned")) {
            jRadioButton1.setSelected(true);
        } else if (id4.equals("Cancelled")) {
            jRadioButton5.setSelected(true);
        } else if (id4.equals("Resolved")) {
            jRadioButton3.setSelected(true);
        } else if (id4.equals("On Hold")) {
            jRadioButton4.setSelected(true);
        } else if (id4.equals("In Progress")) {
            jRadioButton2.setSelected(true);
        }
      
    }//GEN-LAST:event_jTable3MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
dispose();
new Physibility().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        dispose();
        new Physibility_operation().setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField15CaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTextField15CaretUpdate
  jLabel10.setVisible(false);
        
        if(jButton1.isVisible())
        {
            jButton7.setEnabled(false);
             jButton3.setEnabled(false);
        }
        else
        {
         jButton7.setEnabled(true);
            jButton3.setEnabled(true);
            jButton2.setEnabled(true);
        }
        if(!jTextField15.getText().equals(""))
       {
             jLabel1.setVisible(false);
           jLabel1.setText("");
      
       }        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15CaretUpdate

    private void jComboBox2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jComboBox2FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2FocusGained

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
 add1_id_plan();        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed
    public void set_perfect_value() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");

            stat = con.createStatement();
            rs = stat.executeQuery("select * from feasibility,materialoperation where feasibility.order_no=materialoperation.order_no and feasibility.order_no='" + jTextField14.getText() + "'");


            while (model.getRowCount() > 0) {
                model.removeRow(0);
            }

            vec1.removeAllElements();
            while (rs.next()) {
//                TableRow tb = new TableRow();
//
//                jTable1.addRow(tb);

                model.addRow(new String[]{rs.getString(9), rs.getString(10)});

//                vec1.addElement(rs.getString(1));
//                String a[]={rs.getString(16).toString()};
//                System.out.println(a);

                String b = rs.getString(9);
                String bb = rs.getString(10);
                String a[] = {b};
                String aa[] = {bb};
                // System.out.print(a[0]+",");
                for (int i = 0; i < a.length; i++) {
                    jTextField2.setText(jTextField2.getText() + a[i] + ",");

                    System.out.print(a[i]);
                }
        
                for (int i = 0; i < aa.length; i++) {
                    jTextField3.setText(jTextField3.getText() + aa[i] + ",");

                    System.out.print(aa[i]);
                }
                //System.out.print(rs.getString(16)+",");

               update_Ophy();
                   
                
                //System.out.print(rs.getString(17)+",");
            }

  refresh();
                         refresh1();

            //cb[cb.length+1]=new JCheckBox();
            jTable1.setModel(model);
          
            con.close();
            stat.close();
        } catch (Exception e31) {
            System.out.println("Error" + e31);
        }

    }
    public void refresh() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");

            stat = con.createStatement();
             rs = stat.executeQuery("select * from feasibility,involves,con_type,plan_type,user where feasibility.order_no=involves.order_no and feasibility.cust_id=involves.cust_id and involves.PlanID=plan_type.PlanID and involves.ConnectionId=con_type.ConnectionID and involves.cust_id = user.user_id");

            while (model1.getRowCount() > 0) {
                model1.removeRow(0);
            }

            vec2.removeAllElements();
            while (rs.next()) {
//                TableRow tb = new TableRow();
//
//                jTable1.addRow(tb);

                   model1.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(20),rs.getString(21),rs.getString(22),rs.getString(26),rs.getString(14), rs.getString(12), rs.getString(4) , rs.getString(5), rs.getString(6)});

                vec2.addElement(rs.getString(1));
            }
            //cb[cb.length+1]=new JCheckBox();
            jTable3.setModel(model1);
            con.close();
            stat.close();
        } catch (Exception e31) {
            System.out.println("Error" + e31);
        }
    }

    public void refresh1() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");

            stat = con.createStatement();
            rs = stat.executeQuery("select * from feasibility,materialoperation where feasibility.order_no=materialoperation.order_no and feasibility.order_no='" + jTextField14.getText() + "'");


            while (model.getRowCount() > 0) {
                model.removeRow(0);
            }

            vec1.removeAllElements();
            while (rs.next()) {
//                TableRow tb = new TableRow();
//
//                jTable1.addRow(tb);

                model.addRow(new String[]{rs.getString(9), rs.getString(10)});

                vec1.addElement(rs.getString(1));
//                System.out.println(rs.getString(17));
            }


            //cb[cb.length+1]=new JCheckBox();
            jTable1.setModel(model);
            con.close();
            stat.close();
        } catch (Exception e31) {
            System.out.println("Error" + e31);
        }
    }
    
    public void refresh_plan() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");

            stat = con.createStatement();
            rs2 = stat.executeQuery("select * from connection_plan,con_type,plan_type where connection_plan.ConnectionId=con_type.ConnectionID and connection_plan.PlanId=plan_type.PlanID and connection_plan.ConnectionId='"+jLabel2.getText()+"'");

              jComboBox3.removeAllItems();  
            while (rs2.next()) {
                System.out.println(rs2+"");
               
                jComboBox3.addItem(rs2.getString(6));
  

            }
//            jComboBox2.removeAllItems();
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
}
// public void refresh12() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
//            System.out.println("Connected Successfully");
//
//            stat = con.createStatement();
//            rs = stat.executeQuery("select * from physibility where order_id='"+jTextField14.getText()+"'");
//
//            while (model.getRowCount() > 0) {
//                model.removeRow(0);
//            }
//
//            vec1.removeAllElements();
//            while (rs.next()) {
////                TableRow tb = new TableRow();
////
////                jTable1.addRow(tb);
//
//                model.addRow(new String[]{rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(14)});
//
//                vec1.addElement(rs.getString(1));
//            }
//            
//            //cb[cb.length+1]=new JCheckBox();
//            jTable1.setModel(model);
//            con.close();
//            stat.close();
//        } catch (Exception e31) {
//            System.out.println("Error" + e31);
//        }
//    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Physibility_operation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Physibility_operation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Physibility_operation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Physibility_operation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Physibility_operation().setVisible(true);
            }
        });
    }
     public void delete_quanstock() {
        String aa = jLabel5.getText().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_id=" + aa + "");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                tq = rs.getString(4);
                System.out.println(tq);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void delete_stock_update() {
        String qu1 = jTextField15.getText();

        int b1 = Integer.parseInt(qu1);
        System.out.println(b1);
        System.out.println(tq);
        int a1 = Integer.parseInt(tq);
        int c1 = a1 - b1;
        System.out.println(c1);
        String n1 = jComboBox2.getSelectedItem().toString();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_sold=" + c1 + " where item_id='" + jLabel5.getText() + "'");

            refresh();
            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in updating" + ex);

        }
    }
    public void addition() {
        String a = jComboBox2.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_id='" + jLabel5.getText() + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                tm = rs.getString(3);
                int m=Integer.parseInt(tm);
                tn = rs.getString(4);
                 int n=Integer.parseInt(tn);
                
                
                k=m-n;
                 
                System.out.print(k);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

     public void addition1() {
         String n = jComboBox2.getSelectedItem().toString();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_rema='" + k + "' where item_id='" + jLabel5.getText() + "'");

            refresh();
            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in updating" + ex);

        }
    }
    
     
     
     
     
     
     
     
     
     public void before_qyan() {
        String pp = jTextField7.getText().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from materialoperation where id='" + jLabel6.getText() + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                before = rs.getString(4);
 System.out.println("before phy"+before);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void after_qyan() {
        String pp = jTextField7.getText().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from materialoperation where id='" + jLabel6.getText() + "'");


            // jComboBox1.removeAllItems();
            while (rs.next()) {
                after = rs.getString(4);
                System.out.println("after phy"+after);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     public void retrive_quan() {
        String aa = jTextField7.getText().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_id='" + jLabel5.getText() + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                mm = rs.getString(4);
                System.out.println("quantity retrive"+mm);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

    public void add_update() {
       
        String ppp = jTextField7.getText();
        int mm1 = Integer.parseInt(mm);
        int kk = mm1 + diff;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_sold=" + kk + " where item_id='" + jLabel5.getText() + "'");
            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in inserting Material Form" + ex);

        }
    }

    
    
     public void mult() {
        String a = jTextField7.getText().toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();

            rs = stat.executeQuery("select * from stock where item_id='" + jLabel5.getText() + "'");

            // jComboBox1.removeAllItems();
            while (rs.next()) {
                tm = rs.getString(3);
                int m=Integer.parseInt(tm);
                tn = rs.getString(4);
                 int n=Integer.parseInt(tn);
                
                 
                k=m-n;
                 
                System.out.print(k);
            }
            con.close();
            stat.close();
        } catch (Exception ex) {

            System.out.println("Error in item" + ex);
        }
    }

     public void mult1() {
         String n = jTextField7.getText().toString();

        try {

            Class.forName("com.mysql.j"
                    + "dbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/broadsoft", "root", "");
            System.out.println("Connected Successfully");
            stat = con.createStatement();
            stat.executeUpdate("update stock set quantity_rema='" + k + "'where item_id='" +jLabel5.getText() + "'");

            refresh();
            con.close();
            stat.close();
        } catch (Exception ex) {
            System.out.println("Error in updating" + ex);

        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JToolBar jToolBar1;
    // End of variables declaration//GEN-END:variables
}
