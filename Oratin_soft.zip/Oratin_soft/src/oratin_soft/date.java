/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package oratin_soft;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Acer
 */
public class date {
    
date() throws ParseException{


DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

Date dateOne = df.parse("2010-02-08");
Date dateTwo = df.parse("2011-02-15");    

long timeDiff = Math.abs(dateOne.getDate() - dateTwo.getDate());

System.out.println("difference:" + timeDiff);   // difference: 0


}


public static void main(String[] args) throws ParseException {
   new date();
}
}