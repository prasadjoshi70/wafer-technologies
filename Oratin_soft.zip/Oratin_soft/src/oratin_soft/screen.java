package oratin_soft;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class screen extends JFrame  implements PropertyChangeListener{

	private JLabel l1,l2;
             private Task task;
                 int progress = 0;
JProgressBar p1;
    class Task extends SwingWorker<Void, Void> {
        /*
         * Main task. Executed in background thread.
         */
        @Override
        public Void doInBackground() {
            Random random = new Random();
        
            //Initialize progress property.
            setProgress(0);
            while (progress < 100)
            {
                //Sleep for up to one second.
                try {
                    Thread.sleep(random.nextInt(1000));
                } catch (InterruptedException ignore) {}
                //Make random progress.
                progress += random.nextInt(8);
                setProgress(Math.min(progress, 100));
            }
            return null;
        }

        /*
         * Executed in event dispatching thread
         */
        @Override
        public void done() {
           
          
          
            
        }
    }

	
	
	screen()
	{
		
		try
		{
			Container c=getContentPane();
                       
			 p1 = new JProgressBar(0, 100);
        p1.setValue(0);
        p1.setStringPainted(true);
        p1.setFont(new Font("Verdana",Font.PLAIN,9));
        p1.setForeground(Color.BLACK);
      	p1.setBorder(new EmptyBorder(0,0,0,0));
    

			
			JDesktopPane dp=new JDesktopPane();
                          ImageIcon leftButtonIcon = createImageIcon("images/Oratin.png");
			l1=new JLabel(leftButtonIcon);

		  ImageIcon leftButtonIcon1 = createImageIcon("images/transparentLoader.gif");
			l2=new JLabel(leftButtonIcon1);

    
     
        

   
                        
			this.getContentPane().add(l1);
                     l1.add(l2);
                       l2.setBounds(230, 150, 100, 100);
			setUndecorated(true);
		//	getRootPane().setWindowDecorationStyle(JRootPane.ERROR_DIALOG);
			
			Dimension dim=getToolkit().getScreenSize();
			setLocation(dim.width/3-getWidth()/4,dim.height/4-getHeight()/4);
                       
		  task = new Task();
        task.addPropertyChangeListener(this);
        task.execute();
                        add(p1,BorderLayout.SOUTH);

			setSize(570,290);
			setVisible(true);
			
			
                }
                catch(Exception e)
                {
                 
                }
        }
	public void propertyChange(PropertyChangeEvent evt) {
        if ("progress" == evt.getPropertyName()) {
            int progress = (Integer) evt.getNewValue();
            p1.setValue(progress);
           if(p1.getValue()==100)
        {
           dispose();
        new User().setVisible(true);
           
        }
           
        } 
       
         
        
    }
			
			
	public static void main(String[] args) throws ClassNotFoundException {
          
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                try {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                } catch (InstantiationException ex) {
                    Logger.getLogger(screen.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(screen.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(screen.class.getName()).log(Level.SEVERE, null, ex);
                }
                    break;
                }
            }
       
	
		new screen();
 
        }
    private ImageIcon createImageIcon(String path) {
           java.net.URL imgURL = screen.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }


	

}
